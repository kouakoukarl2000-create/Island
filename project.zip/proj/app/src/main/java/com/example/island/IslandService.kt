package com.example.island

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlin.math.abs
import kotlin.math.sin

/** Petit égaliseur animé (4 barres). */
class EqView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var active = false
    private val anim = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 900; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    fun setColor(c: Int) { p.color = c; invalidate() }
    fun setActive(a: Boolean) {
        active = a
        if (a) { if (!anim.isStarted) anim.start() } else { anim.cancel(); invalidate() }
    }
    override fun onDraw(canvas: Canvas) {
        val n = 4; val bw = width / (n * 2 - 1f)
        for (i in 0 until n) {
            val f = if (active) 0.25f + 0.75f * abs(sin(phase + i * 1.1f)) else 0.25f
            val h = height * f; val x = i * bw * 2
            canvas.drawRoundRect(RectF(x, (height - h) / 2, x + bw, (height + h) / 2), bw / 2, bw / 2, p)
        }
    }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
}

/** Barre de progression fine. */
class ProgressView(c: Context) : View(c) {
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#44FFFFFF") }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    var progress = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    override fun onDraw(canvas: Canvas) {
        val r = height / 2f
        canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), r, r, track)
        canvas.drawRoundRect(RectF(0f, 0f, width * progress, height.toFloat()), r, r, fill)
    }
}

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private lateinit var pill: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var clockBox: LinearLayout
    private lateinit var musicBox: LinearLayout
    private lateinit var miniBar: LinearLayout
    private lateinit var artBig: ImageView
    private lateinit var artMini: ImageView
    private lateinit var eqBig: EqView
    private lateinit var eqMini: EqView
    private lateinit var musicTitle: TextView
    private lateinit var musicArtist: TextView
    private lateinit var btnPlay: ImageView
    private lateinit var progressView: ProgressView
    private val bg = GradientDrawable().apply { setColor(Color.BLACK) }
    private val handler = Handler(Looper.getMainLooper())
    private var expanded = false

    private var controller: MediaController? = null
    private var playing = false
    private var hasMusic = false

    // Réglages : tailles en dp et distance depuis le haut de l'écran
    private val idleW = 120; private val musicW = 190; private val smallH = 35
    private val bigW = 340;  private val bigH = 152
    private val topOffset = 8

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (root == null) addIsland()
        setupMusic()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "Dynamic Island", NotificationManager.IMPORTANCE_MIN))
        val n: Notification = NotificationCompat.Builder(this, "island")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Dynamic Island active")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }

    private fun roundedArt(sizeDp: Int, radiusDp: Int) = ImageView(this).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        setBackgroundColor(Color.parseColor("#2A2A2E"))
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dp(radiusDp).toFloat())
            }
        }
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    private fun iconBtn(res: Int, sizeDp: Int, onClick: () -> Unit) = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
        setPadding(dp(8), dp(8), dp(8), dp(8))
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply {
            marginStart = dp(10); marginEnd = dp(10)
        }
        setOnClickListener { onClick() }
    }

    private fun addIsland() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // ----- Horloge (aucune musique) -----
        clockBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(TextClock(context).apply {
                format12Hour = "h:mm"; format24Hour = "HH:mm"
                textSize = 34f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            })
            addView(TextClock(context).apply {
                format12Hour = "EEEE d MMMM"; format24Hour = "EEEE d MMMM"
                textSize = 13f; setTextColor(Color.parseColor("#9A9AA6")); gravity = Gravity.CENTER
            })
        }

        // ----- Lecteur développé -----
        artBig = roundedArt(52, 12)
        eqBig = EqView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(22), dp(18)) }
        musicTitle = label("", 16f, Color.WHITE, true)
        musicArtist = label("", 13f, Color.parseColor("#9A9AA6"))
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12); marginEnd = dp(8) }
            addView(musicTitle); addView(musicArtist)
        }
        val topRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(artBig); addView(texts); addView(eqBig)
        }
        progressView = ProgressView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(12) }
        }
        btnPlay = iconBtn(android.R.drawable.ic_media_pause, 52) {
            if (playing) controller?.transportControls?.pause() else controller?.transportControls?.play()
        }
        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) }
            addView(iconBtn(android.R.drawable.ic_media_previous, 44) { controller?.transportControls?.skipToPrevious() })
            addView(btnPlay)
            addView(iconBtn(android.R.drawable.ic_media_next, 44) { controller?.transportControls?.skipToNext() })
        }
        musicBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(10))
            visibility = View.GONE
            addView(topRow); addView(progressView); addView(controls)
        }

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            alpha = 0f
            addView(clockBox); addView(musicBox)
        }

        // ----- Mode réduit : pochette à gauche, égaliseur à droite -----
        artMini = roundedArt(25, 8)
        eqMini = EqView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(20), dp(16)) }
        miniBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(16), 0)
            visibility = View.GONE
            addView(artMini)
            addView(View(context), LinearLayout.LayoutParams(0, 1, 1f))
            addView(eqMini)
        }

        pill = FrameLayout(this).apply {
            background = bg
            addView(content, FrameLayout.LayoutParams(-1, -1))
            addView(miniBar, FrameLayout.LayoutParams(-1, -1))
            layoutParams = FrameLayout.LayoutParams(dp(idleW), dp(smallH))
            setOnClickListener { toggle() }
        }
        bg.cornerRadius = dp(smallH) / 2f
        root = FrameLayout(this).apply { addView(pill) }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(topOffset)
        }
        wm.addView(root, lp)
    }

    // ---------- Musique ----------
    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = refresh()
        override fun onMetadataChanged(metadata: MediaMetadata?) = refresh()
    }
    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private fun setupMusic() {
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(this, MusicListener::class.java)
            msm.removeOnActiveSessionsChangedListener(sessionsListener)
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            pick(msm.getActiveSessions(cn))
        } catch (e: SecurityException) {
            // accès aux notifications pas encore autorisé : mode horloge
        }
    }

    private fun pick(list: List<MediaController>?) {
        controller?.unregisterCallback(callback)
        controller = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        controller?.registerCallback(callback)
        refresh()
    }

    private fun accent(b: Bitmap?): Int {
        if (b == null) return Color.parseColor("#FF375F")
        return try {
            val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3); Color.colorToHSV(px, hsv)
            hsv[1] = maxOf(hsv[1], 0.5f); hsv[2] = 1f
            Color.HSVToColor(hsv)
        } catch (e: Exception) { Color.parseColor("#FF375F") }
    }

    private fun refresh() {
        handler.post {
            val c = controller
            val st = c?.playbackState?.state
            playing = st == PlaybackState.STATE_PLAYING
            val md = c?.metadata
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
            val bmp = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            hasMusic = title != null && (playing || st == PlaybackState.STATE_PAUSED)

            musicTitle.text = title ?: ""
            musicArtist.text = artist
            artBig.setImageBitmap(bmp); artMini.setImageBitmap(bmp)
            val col = accent(bmp)
            eqBig.setColor(col); eqMini.setColor(col)
            eqBig.setActive(playing && hasMusic); eqMini.setActive(playing && hasMusic)
            btnPlay.setImageResource(
                if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
            btnPlay.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)

            clockBox.visibility = if (hasMusic) View.GONE else View.VISIBLE
            musicBox.visibility = if (hasMusic) View.VISIBLE else View.GONE
            miniBar.visibility = if (hasMusic && !expanded) View.VISIBLE else View.GONE
            animateToTarget()
            handler.removeCallbacks(ticker)
            if (expanded && playing) handler.post(ticker)
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val c = controller; val st = c?.playbackState
            val dur = c?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            if (st != null && dur > 0) {
                var pos = st.position
                if (st.state == PlaybackState.STATE_PLAYING)
                    pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
                progressView.progress = pos.toFloat() / dur
            } else progressView.progress = 0f
            if (expanded && playing) handler.postDelayed(this, 500)
        }
    }

    // ---------- Animation ----------
    private fun animateToTarget() {
        val w1 = dp(if (expanded) bigW else if (hasMusic) musicW else idleW)
        val h1 = dp(if (expanded) (if (hasMusic) bigH else 110) else smallH)
        val w0 = pill.layoutParams.width; val h0 = pill.layoutParams.height
        if (w0 == w1 && h0 == h1) return
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450
            interpolator = OvershootInterpolator(1.1f)
            addUpdateListener {
                val f = it.animatedValue as Float
                val w = (w0 + (w1 - w0) * f).toInt()
                val h = (h0 + (h1 - h0) * f).toInt()
                pill.layoutParams = FrameLayout.LayoutParams(w, h)
                bg.cornerRadius = minOf(h / 2f, dp(36).toFloat())
            }
            start()
        }
    }

    private val autoClose = Runnable { if (expanded) toggle() }

    private fun toggle() {
        expanded = !expanded
        handler.removeCallbacks(autoClose); handler.removeCallbacks(ticker)
        miniBar.visibility = if (hasMusic && !expanded) View.VISIBLE else View.GONE
        animateToTarget()
        content.animate().alpha(if (expanded) 1f else 0f)
            .setStartDelay(if (expanded) 150 else 0).setDuration(250).start()
        if (expanded) {
            handler.post(ticker)
            handler.postDelayed(autoClose, 7000)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            getSystemService(MediaSessionManager::class.java)
                .removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {}
        controller?.unregisterCallback(callback)
        root?.let { wm.removeView(it) }
        root = null
        super.onDestroy()
    }
}
