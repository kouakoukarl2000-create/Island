package com.example.island

import android.app.Notification
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Infos de navigation lues dans la notification de Google Maps. */
data class NavInfo(val title: String, val text: String, val sub: String, val icon: Bitmap?)

/** Pont entre le service d'écoute des notifications et l'îlot. */
object NavBridge {
    var current: NavInfo? = null
    var listener: ((NavInfo?) -> Unit)? = null
    fun update(n: NavInfo?) { current = n; listener?.invoke(n) }
}

/**
 * Sert à lire les lecteurs de musique actifs (autorisation) et la notification
 * de navigation de Google Maps.
 */
class MusicListener : NotificationListenerService() {
    private val maps = "com.google.android.apps.maps"

    override fun onListenerConnected() { scan() }
    override fun onNotificationPosted(sbn: StatusBarNotification) { if (sbn.packageName == maps) scan() }
    override fun onNotificationRemoved(sbn: StatusBarNotification) { if (sbn.packageName == maps) scan() }

    private fun scan() {
        val list = try { activeNotifications?.filter { it.packageName == maps } } catch (e: Exception) { null }
        val sbn = list?.firstOrNull { it.notification.category == Notification.CATEGORY_NAVIGATION }
            ?: list?.firstOrNull { it.isOngoing }
        NavBridge.update(sbn?.let { parse(it) })
    }

    private fun parse(sbn: StatusBarNotification): NavInfo {
        val n = sbn.notification
        val e = n.extras
        fun s(key: String) = e.getCharSequence(key)?.toString()?.trim() ?: ""
        val title = s(Notification.EXTRA_TITLE).ifBlank { s(Notification.EXTRA_TITLE_BIG) }
        val text = s(Notification.EXTRA_TEXT).ifBlank { s(Notification.EXTRA_BIG_TEXT) }
        val sub = s(Notification.EXTRA_SUB_TEXT).ifBlank { s(Notification.EXTRA_INFO_TEXT) }
        val icon = try {
            (n.getLargeIcon() ?: n.smallIcon)?.loadDrawable(this)?.let { toBitmap(it) }
        } catch (ex: Exception) { null }
        return NavInfo(title.ifBlank { "Navigation" }, text, sub, icon)
    }

    private fun toBitmap(d: Drawable): Bitmap {
        val w = maxOf(d.intrinsicWidth, 1); val h = maxOf(d.intrinsicHeight, 1)
        val k = minOf(1f, 128f / maxOf(w, h))
        val bw = maxOf((w * k).toInt(), 1); val bh = maxOf((h * k).toInt(), 1)
        val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, bw, bh); d.draw(Canvas(b))
        return b
    }
}
