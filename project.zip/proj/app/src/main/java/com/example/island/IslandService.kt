package com.example.island

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.sin

/** Égaliseur animé (4 barres). */
class EqView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF375F") }
    private var phase = 0f
    private val anim = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 900; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    private var active = false
    fun setColor(c: Int) { p.color = c; invalidate() }
    fun setActive(a: Boolean) {
        if (a == active) return
        active = a
        if (a) anim.start() else { anim.cancel(); invalidate() }
    }
    override fun onDraw(canvas: Canvas) {
        val n = 4; val bw = width / (n * 2 - 1f)
        for (i in 0 until n) {
            val f = if (active) 0.25f + 0.75f * abs(sin(phase + i * 1.1f)) else 0.25f
            val h = height * f; val x = i * bw * 2
            canvas.drawRoundRect(RectF(x, (height - h) / 2, x + bw, (height + h) / 2), bw / 2, bw / 2, p)
        }
    }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
}

/** Barre de progression fine. */
class ProgressView(c: Context) : View(c) {
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#44FFFFFF") }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    var progress = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    override fun onDraw(canvas: Canvas) {
        val r = height / 2f
        canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), r, r, track)
        canvas.drawRoundRect(RectF(0f, 0f, width * progress, height.toFloat()), r, r, fill)
    }
}

/** Icônes de lecture dessinées à la main : 0 précédent, 1 lecture, 2 pause, 3 suivant. */
class IconView(c: Context, private var kind: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.FILL_AND_STROKE
        strokeJoin = Paint.Join.ROUND; strokeWidth = 3f
    }
    fun set(k: Int) { kind = k; invalidate() }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f; val s = minOf(width, height) * 0.26f
        val path = Path()
        when (kind) {
            0 -> {
                c.drawRoundRect(RectF(cx - s, cy - s, cx - s * 0.6f, cy + s), 2f, 2f, p)
                path.moveTo(cx + s, cy - s); path.lineTo(cx + s, cy + s); path.lineTo(cx - s * 0.45f, cy)
                path.close(); c.drawPath(path, p)
            }
            1 -> {
                path.moveTo(cx - s * 0.8f, cy - s); path.lineTo(cx - s * 0.8f, cy + s); path.lineTo(cx + s, cy)
                path.close(); c.drawPath(path, p)
            }
            2 -> {
                c.drawRoundRect(RectF(cx - s * 0.8f, cy - s, cx - s * 0.2f, cy + s), 2f, 2f, p)
                c.drawRoundRect(RectF(cx + s * 0.2f, cy - s, cx + s * 0.8f, cy + s), 2f, 2f, p)
            }
            else -> {
                c.drawRoundRect(RectF(cx + s * 0.6f, cy - s, cx + s, cy + s), 2f, 2f, p)
                path.moveTo(cx - s, cy - s); path.lineTo(cx - s, cy + s); path.lineTo(cx + s * 0.45f, cy)
                path.close(); c.drawPath(path, p)
            }
        }
    }
}

/** Petite batterie pour l'état « en charge ». */
class BatteryView(c: Context) : View(c) {
    var level = 80
        set(v) { field = v.coerceIn(0, 100); invalidate() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 4f
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#30D158") }
    private val tip = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    override fun onDraw(c: Canvas) {
        val w = width - 8f; val h = height.toFloat()
        c.drawRoundRect(RectF(2f, 2f, w - 2f, h - 2f), h * 0.3f, h * 0.3f, stroke)
        c.drawRoundRect(RectF(7f, 7f, 7f + (w - 14f) * level / 100f, h - 7f), h * 0.15f, h * 0.15f, fill)
        c.drawRoundRect(RectF(w, h * 0.35f, w + 5f, h * 0.65f), 2f, 2f, tip)
    }
}

class IslandService : Service() {
    companion object {
        const val ACTION_TIMER = "com.example.island.TIMER"
        const val ACTION_STOP_TIMER = "com.example.island.STOP_TIMER"
    }

    private enum class S { IDLE, MUSIC_S, MUSIC_L, CLOCK_L, TIMER_S, TIMER_L, CHARGE, NAV_S, NAV_L }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private var root: FrameLayout? = null
    private lateinit var pill: FrameLayout
    private val bg = GradientDrawable().apply { setColor(Color.BLACK) }
    private val handler = Handler(Looper.getMainLooper())

    // Réglages (modifiables depuis l'app)
    private var scale = 1f
    private var topDp = 8
    private var xDp = 0

    // Calques (un par état)
    private val layers = mutableListOf<View>()
    private lateinit var vMusicS: View
    private lateinit var vMusicL: View
    private lateinit var vClockL: View
    private lateinit var vTimerS: View
    private lateinit var vTimerL: View
    private lateinit var vCharge: View
    private lateinit var vNavS: View
    private lateinit var vNavL: View
    private lateinit var navArtS: ImageView
    private lateinit var navArtL: ImageView
    private lateinit var navTitleS: TextView
    private lateinit var navTitleL: TextView
    private lateinit var navTextL: TextView
    private lateinit var navSubL: TextView
    private var nav: NavInfo? = null
    private lateinit var artS: ImageView
    private lateinit var artL: ImageView
    private lateinit var eqS: EqView
    private lateinit var eqL: EqView
    private lateinit var titleL: TextView
    private lateinit var artistL: TextView
    private lateinit var playIcon: IconView
    private lateinit var progressView: ProgressView
    private lateinit var tmS: TextView
    private lateinit var tmL: TextView
    private lateinit var batt: BatteryView
    private lateinit var chargeTxt: TextView

    // États
    private var expanded = false
    private var controller: MediaController? = null
    private var playing = false
    private var hasMusic = false
    private var timerEnd = 0L
    private var chargeShowing = false
    private var receiverRegistered = false
    private var anim: ValueAnimator? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density * scale).toInt()
    private fun dpa(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    // ---------- Cycle de vie ----------
    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("island", MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        nav = NavBridge.current
        NavBridge.listener = { n ->
            handler.post {
                val had = nav != null
                nav = n
                if ((n != null) != had) expanded = false
                refresh()
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (root == null) { loadPrefs(); addIsland() }
        setupMusic()
        registerCharge()
        when (intent?.action) {
            ACTION_TIMER -> startTimer(intent?.getIntExtra("sec", 60) ?: 60)
            ACTION_STOP_TIMER -> stopTimer()
        }
        refresh()
        return START_STICKY
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        handler.post {
            loadPrefs()
            if (key == null || key == "scale") rebuild() else updatePosition()
        }
    }

    private fun loadPrefs() {
        scale = prefs.getInt("scale", 100) / 100f
        topDp = prefs.getInt("top", 8)
        xDp = prefs.getInt("x", 0)
    }

    private fun updatePosition() {
        val r = root ?: return
        val lp = r.layoutParams as? WindowManager.LayoutParams ?: return
        lp.y = dpa(topDp); lp.x = dpa(xDp)
        wm.updateViewLayout(r, lp)
    }

    private fun rebuild() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        addIsland()
        refresh()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "Dynamic Island", NotificationManager.IMPORTANCE_MIN))
        val n: Notification = NotificationCompat.Builder(this, "island")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Dynamic Island active")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ---------- Construction des vues ----------
    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text; textSize = size * scale; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }

    private fun roundedArt(sizeDp: Int, radiusDp: Int) = ImageView(this).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#FF375F"), Color.parseColor("#5E5CE6")))
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dp(radiusDp).toFloat())
            }
        }
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    private fun navArt(sizeDp: Int, radiusDp: Int) = roundedArt(sizeDp, radiusDp).apply {
        setBackgroundColor(Color.parseColor("#0A84FF"))
        scaleType = ImageView.ScaleType.FIT_CENTER
        val p = dp(4); setPadding(p, p, p, p)
    }

    private fun bindNav() {
        val n = nav ?: return
        navTitleS.text = n.title.ifBlank { n.text }
        navTitleL.text = n.title
        navTextL.text = n.text
        navTextL.visibility = if (n.text.isBlank()) View.GONE else View.VISIBLE
        navSubL.text = n.sub
        navSubL.visibility = if (n.sub.isBlank()) View.GONE else View.VISIBLE
        for (v in listOf(navArtS, navArtL)) {
            if (n.icon != null) v.setImageBitmap(n.icon)
            else v.setImageResource(android.R.drawable.ic_menu_directions)
        }
    }

    private fun icon(kind: Int, sizeDp: Int, onClick: () -> Unit) = IconView(this, kind).apply {
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply {
            marginStart = dp(8); marginEnd = dp(8)
        }
        setOnClickListener { onClick() }
    }

    private fun spacer() = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }

    private fun addIsland() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        layers.clear()
        val white = Color.WHITE; val grey = Color.parseColor("#9A9AA6")
        val orange = Color.parseColor("#FF9F0A"); val green = Color.parseColor("#30D158")

        // Musique réduite : pochette à gauche, égaliseur à droite
        artS = roundedArt(25, 8)
        eqS = EqView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(20), dp(16)) }
        vMusicS = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(16), 0)
            addView(artS); addView(spacer()); addView(eqS)
        }

        // Musique développée
        artL = roundedArt(56, 14)
        eqL = EqView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(22), dp(18)) }
        titleL = label("", 15f, white, true)
        artistL = label("", 13f, grey)
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12); marginEnd = dp(8) }
            addView(titleL); addView(artistL)
        }
        progressView = ProgressView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(12) }
        }
        playIcon = icon(2, 52) {
            if (playing) controller?.transportControls?.pause() else controller?.transportControls?.play()
        }
        vMusicL = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(8))
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(artL); addView(texts); addView(eqL)
            })
            addView(progressView)
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) }
                addView(icon(0, 44) { controller?.transportControls?.skipToPrevious() })
                addView(playIcon)
                addView(icon(3, 44) { controller?.transportControls?.skipToNext() })
            })
        }

        // Horloge développée
        vClockL = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            addView(TextClock(context).apply {
                format12Hour = "h:mm"; format24Hour = "HH:mm"
                textSize = 38f * scale; setTextColor(white); gravity = Gravity.CENTER
            })
            addView(TextClock(context).apply {
                format12Hour = "EEEE d MMMM"; format24Hour = "EEEE d MMMM"
                textSize = 13f * scale; setTextColor(grey); gravity = Gravity.CENTER
            })
        }

        // Minuteur réduit
        tmS = label("0:00", 14f, orange, true).apply { fontFeatureSettings = "tnum" }
        vTimerS = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(16), 0)
            addView(label("⏱", 15f, orange)); addView(spacer()); addView(tmS)
        }

        // Minuteur développé
        tmL = label("0:00", 40f, orange, true).apply { fontFeatureSettings = "tnum"; gravity = Gravity.CENTER }
        val stop = label("Arrêter", 14f, white, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(8), dp(22), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#FF453A")); cornerRadius = dp(18).toFloat()
            }
            setOnClickListener { stopTimer() }
        }
        vTimerL = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            addView(tmL)
            addView(stop, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        }

        // En charge
        batt = BatteryView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(36), dp(18)) }
        chargeTxt = label("", 14f, green, true)
        vCharge = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
            addView(batt)
            addView(label("  En charge", 14f, white, true))
            addView(spacer()); addView(chargeTxt)
        }

        // Navigation (Google Maps)
        navArtS = navArt(25, 8)
        navTitleS = label("", 13f, white, true).apply {
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) }
        }
        vNavS = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(16), 0)
            addView(navArtS); addView(navTitleS)
        }
        navArtL = navArt(52, 13)
        navTitleL = label("", 17f, white, true)
        navTextL = label("", 13f, grey).apply { maxLines = 2 }
        navSubL = label("", 13f, green, true)
        vNavL = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(12))
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(navArtL)
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) }
                    addView(navTitleL); addView(navTextL)
                })
            })
            addView(navSubL, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        }

        pill = FrameLayout(this).apply {
            background = bg
            setOnClickListener { toggle() }
        }
        for (v in listOf(vMusicS, vMusicL, vClockL, vTimerS, vTimerL, vCharge, vNavS, vNavL)) {
            v.alpha = 0f; v.visibility = View.GONE
            pill.addView(v, FrameLayout.LayoutParams(-1, -1))
            layers.add(v)
        }
        pill.layoutParams = FrameLayout.LayoutParams(dp(120), dp(35)).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        }
        bg.cornerRadius = dp(35) / 2f

        val r = FrameLayout(this).apply {
            addView(pill)
            minimumWidth = dp(120); minimumHeight = dp(35)
        }
        root = r

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dpa(topDp); x = dpa(xDp)
        }
        wm.addView(r, lp)
    }

    // ---------- État courant ----------
    private fun state(): S = when {
        chargeShowing -> S.CHARGE
        nav != null -> if (expanded) S.NAV_L else S.NAV_S
        timerEnd > 0 -> if (expanded) S.TIMER_L else S.TIMER_S
        hasMusic -> if (expanded) S.MUSIC_L else S.MUSIC_S
        else -> if (expanded) S.CLOCK_L else S.IDLE
    }

    private fun sizeOf(s: S): Pair<Int, Int> = when (s) {
        S.IDLE -> 120 to 35
        S.MUSIC_S, S.TIMER_S -> 190 to 35
        S.MUSIC_L -> 340 to 152
        S.CLOCK_L -> 300 to 104
        S.TIMER_L -> 300 to 116
        S.CHARGE -> 230 to 48
        S.NAV_S -> 210 to 35
        S.NAV_L -> 340 to 124
    }

    private fun layerFor(s: S): View? = when (s) {
        S.IDLE -> null
        S.MUSIC_S -> vMusicS
        S.MUSIC_L -> vMusicL
        S.CLOCK_L -> vClockL
        S.TIMER_S -> vTimerS
        S.TIMER_L -> vTimerL
        S.CHARGE -> vCharge
        S.NAV_S -> vNavS
        S.NAV_L -> vNavL
    }

    private fun apply() {
        if (root == null) return
        val s = state()
        showLayer(layerFor(s))
        val (w, h) = sizeOf(s)
        animateTo(dp(w), dp(h))
    }

    /** Fondu + léger zoom entre les contenus, comme sur la démo web. */
    private fun showLayer(target: View?) {
        for (v in layers) {
            if (v === target) {
                if (v.visibility != View.VISIBLE) {
                    v.alpha = 0f; v.scaleX = 0.92f; v.scaleY = 0.92f; v.visibility = View.VISIBLE
                }
                v.animate().alpha(1f).scaleX(1f).scaleY(1f)
                    .setStartDelay(120).setDuration(300).start()
            } else if (v.visibility == View.VISIBLE) {
                v.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f)
                    .setStartDelay(0).setDuration(150)
                    .withEndAction { if (v.alpha < 0.05f) v.visibility = View.GONE }.start()
            }
        }
    }

    private fun setPill(w: Int, h: Int) {
        val lp = pill.layoutParams as FrameLayout.LayoutParams
        lp.width = w; lp.height = h
        pill.layoutParams = lp
        bg.cornerRadius = minOf(h / 2f, dp(38).toFloat())
    }

    /**
     * Animation fluide : on réserve d'abord la place dans la fenêtre (une seule fois),
     * puis seule la pilule bouge à l'intérieur, sans redimensionner la fenêtre à chaque image.
     */
    private fun animateTo(w1: Int, h1: Int) {
        val r = root ?: return
        val lp = pill.layoutParams as FrameLayout.LayoutParams
        val w0 = lp.width; val h0 = lp.height
        if (w0 == w1 && h0 == h1) return
        anim?.cancel()
        r.minimumWidth = (maxOf(w0, w1) * 1.12f).toInt()
        r.minimumHeight = (maxOf(h0, h1) * 1.15f).toInt()
        r.requestLayout()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 520
            interpolator = PathInterpolator(0.34f, 1.45f, 0.5f, 1f)
            addUpdateListener {
                val f = it.animatedValue as Float
                setPill((w0 + (w1 - w0) * f).toInt(), (h0 + (h1 - h0) * f).toInt())
            }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: Animator) { cancelled = true }
                override fun onAnimationEnd(a: Animator) {
                    if (cancelled) return
                    setPill(w1, h1)
                    root?.let { it.minimumWidth = w1; it.minimumHeight = h1; it.requestLayout() }
                }
            })
            start()
        }
    }

    private val autoClose = Runnable { if (expanded) toggle() }

    private fun toggle() {
        if (state() == S.CHARGE) return
        expanded = !expanded
        handler.removeCallbacks(autoClose)
        apply()
        if (expanded) handler.postDelayed(autoClose, 8000)
        updateTicker()
    }

    // ---------- Musique ----------
    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = refresh()
        override fun onMetadataChanged(metadata: MediaMetadata?) = refresh()
    }
    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private fun setupMusic() {
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(this, MusicListener::class.java)
            msm.removeOnActiveSessionsChangedListener(sessionsListener)
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            pick(msm.getActiveSessions(cn))
        } catch (e: SecurityException) {
            // accès aux notifications pas encore autorisé
        }
    }

    private fun pick(list: List<MediaController>?) {
        controller?.unregisterCallback(callback)
        controller = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        controller?.registerCallback(callback)
        refresh()
    }

    private fun accent(b: Bitmap?): Int {
        if (b == null) return Color.parseColor("#FF375F")
        return try {
            val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3); Color.colorToHSV(px, hsv)
            hsv[1] = maxOf(hsv[1], 0.5f); hsv[2] = 1f
            Color.HSVToColor(hsv)
        } catch (e: Exception) { Color.parseColor("#FF375F") }
    }

    private fun refresh() {
        handler.post {
            if (root == null) return@post
            val c = controller
            val st = c?.playbackState?.state
            playing = st == PlaybackState.STATE_PLAYING
            val md = c?.metadata
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
            val bmp = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            hasMusic = title != null && (playing || st == PlaybackState.STATE_PAUSED)

            titleL.text = title ?: ""
            artistL.text = artist
            artS.setImageBitmap(bmp); artL.setImageBitmap(bmp)
            val col = accent(bmp)
            eqS.setColor(col); eqL.setColor(col)
            val act = playing && hasMusic
            eqS.setActive(act); eqL.setActive(act)
            playIcon.set(if (playing) 2 else 1)
            bindNav()
            apply()
            updateTicker()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val c = controller; val st = c?.playbackState
            val dur = c?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            if (st != null && dur > 0) {
                var pos = st.position
                if (st.state == PlaybackState.STATE_PLAYING)
                    pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
                progressView.progress = pos.toFloat() / dur
            } else progressView.progress = 0f
            if (state() == S.MUSIC_L && playing) handler.postDelayed(this, 500)
        }
    }

    private fun updateTicker() {
        handler.removeCallbacks(ticker)
        if (state() == S.MUSIC_L) handler.post(ticker)
    }

    // ---------- Minuteur ----------
    private val timerTick = object : Runnable {
        override fun run() {
            val left = ((timerEnd - SystemClock.elapsedRealtime() + 999) / 1000).toInt()
            if (left <= 0) { timerEnd = 0; expanded = false; apply(); return }
            val txt = "%d:%02d".format(left / 60, left % 60)
            tmS.text = txt; tmL.text = txt
            handler.postDelayed(this, 250)
        }
    }

    private fun startTimer(sec: Int) {
        timerEnd = SystemClock.elapsedRealtime() + sec * 1000L
        expanded = false
        handler.removeCallbacks(timerTick); handler.post(timerTick)
        apply()
    }

    private fun stopTimer() {
        timerEnd = 0
        handler.removeCallbacks(timerTick)
        expanded = false
        apply()
    }

    // ---------- Charge ----------
    private val chargeHide = Runnable { chargeShowing = false; apply() }

    private val chargeReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            val max = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (max > 0) level * 100 / max else level
            batt.level = pct; chargeTxt.text = "$pct%"
            chargeShowing = true
            apply()
            handler.removeCallbacks(chargeHide)
            handler.postDelayed(chargeHide, 2800)
        }
    }

    private fun registerCharge() {
        if (receiverRegistered) return
        ContextCompat.registerReceiver(this, chargeReceiver,
            IntentFilter(Intent.ACTION_POWER_CONNECTED), ContextCompat.RECEIVER_NOT_EXPORTED)
        receiverRegistered = true
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        anim?.cancel()
        NavBridge.listener = null
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        try { if (receiverRegistered) unregisterReceiver(chargeReceiver) } catch (_: Exception) {}
        receiverRegistered = false
        try {
            getSystemService(MediaSessionManager::class.java)
                .removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {}
        controller?.unregisterCallback(callback)
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        super.onDestroy()
    }
}
