package com.example.island

import android.app.Notification
import android.app.PendingIntent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Infos de navigation lues dans la notification de Google Maps. */
data class NavInfo(val title: String, val text: String, val sub: String, val icon: Bitmap?)

/** Infos d'appel lues dans la notification d'appel (Téléphone, WhatsApp...). */
data class CallInfo(
    val name: String, val status: String, val since: Long, val icon: Bitmap?,
    val hangup: PendingIntent?, val answer: PendingIntent?
)


/** Événements système affichables dans l'îlot. */
data class SystemEvent(val kind: Kind, val title: String, val text: String = "", val until: Long = 0L) {
    enum class Kind { TIMER, RECORDING }
}

object SystemEventBridge {
    var current: SystemEvent? = null
    var listener: ((SystemEvent?) -> Unit)? = null
    fun update(e: SystemEvent?) { current = e; listener?.invoke(e) }
}

object CallBridge {
    var current: CallInfo? = null
    var listener: ((CallInfo?) -> Unit)? = null
    fun update(c: CallInfo?) { current = c; listener?.invoke(c) }
}

/** Pont entre le service d'écoute des notifications et l'îlot. */
object NavBridge {
    var current: NavInfo? = null
    var listener: ((NavInfo?) -> Unit)? = null
    fun update(n: NavInfo?) { current = n; listener?.invoke(n) }
}

/**
 * Sert à lire les lecteurs de musique actifs (autorisation) et la notification
 * de navigation de Google Maps.
 */
class MusicListener : NotificationListenerService() {
    private val maps = "com.google.android.apps.maps"

    override fun onListenerConnected() {
        scanNav(); scanCall(); scanSystemEvents()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        check(sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        check(sbn)
        if (isSystemEvent(sbn)) scanSystemEvents()
    }

    private fun check(sbn: StatusBarNotification) {
        if (sbn.packageName == maps) scanNav()
        if (sbn.notification.category == Notification.CATEGORY_CALL) scanCall()
        if (isSystemEvent(sbn)) scanSystemEvents()
    }

    private fun isSystemEvent(sbn: StatusBarNotification): Boolean {
        val n = sbn.notification
        val e = n.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.lowercase().orEmpty()
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.lowercase().orEmpty()
        val big = e.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.lowercase().orEmpty()
        val pkg = sbn.packageName.lowercase()
        val all = "$title $text $big $pkg"
        return all.contains("timer") || all.contains("minuteur") || all.contains("countdown") ||
            all.contains("chronom") || all.contains("record") || all.contains("enregistr") ||
            all.contains("recorder") || all.contains("enregistrement") ||
            pkg.contains("deskclock") || pkg.contains("clock") || pkg.contains("soundrecorder") ||
            pkg.contains("audiorecorder")
    }

    private fun scanSystemEvents() {
        val active = try { activeNotifications?.toList().orEmpty() } catch (_: Exception) { emptyList() }
        val event = active.asSequence()
            .mapNotNull { parseSystemEvent(it) }
            .firstOrNull { it.until == 0L || it.until > System.currentTimeMillis() }
        SystemEventBridge.update(event)
    }

    private fun parseSystemEvent(sbn: StatusBarNotification): SystemEvent? {
        val n = sbn.notification
        val e = n.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val pkg = sbn.packageName.lowercase()
        val all = "$title $text $pkg".lowercase()
        val timer = all.contains("timer") || all.contains("minuteur") || all.contains("countdown") ||
            all.contains("chronom") || pkg.contains("deskclock") || pkg.contains("clock") ||
            n.category == Notification.CATEGORY_ALARM
        val recording = all.contains("record") || all.contains("enregistr") || all.contains("recorder") ||
            pkg.contains("soundrecorder") || pkg.contains("audiorecorder")
        if (!timer && !recording) return null
        return if (recording) {
            SystemEvent(SystemEvent.Kind.RECORDING, title.ifBlank { "Enregistrement" }, text)
        } else {
            SystemEvent(SystemEvent.Kind.TIMER, title.ifBlank { "Minuteur" }, text)
        }
    }

    private fun scanCall() {
        val list = try {
            activeNotifications?.filter { it.notification.category == Notification.CATEGORY_CALL }
        } catch (e: Exception) { null }
        val sbn = list?.firstOrNull { it.isOngoing } ?: list?.firstOrNull()
        CallBridge.update(sbn?.let { parseCall(it) })
    }

    private fun findAction(n: Notification, keys: List<String>): PendingIntent? =
        n.actions?.firstOrNull { a ->
            val t = a.title?.toString()?.lowercase() ?: ""
            keys.any { t.contains(it) }
        }?.actionIntent

    private fun parseCall(sbn: StatusBarNotification): CallInfo {
        val n = sbn.notification
        val e = n.extras
        val name = e.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val status = e.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val since = if (e.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)) n.`when` else 0L
        val icon = try {
            (n.getLargeIcon() ?: n.smallIcon)?.loadDrawable(this)?.let { toBitmap(it) }
        } catch (ex: Exception) { null }
        val answer = findAction(n, listOf("répond", "repond", "answer", "accept", "décroch", "decroch"))
        val hang = findAction(n, listOf("raccroch", "hang", "end", "terminer", "refus", "decline", "reject", "dismiss"))
        return CallInfo(name.ifBlank { "Appel" }, status, since, icon, hang, answer)
    }

    private fun scanNav() {
        val list = try { activeNotifications?.filter { it.packageName == maps } } catch (e: Exception) { null }
        val sbn = list?.firstOrNull { it.notification.category == Notification.CATEGORY_NAVIGATION }
            ?: list?.firstOrNull { it.isOngoing }
        NavBridge.update(sbn?.let { parse(it) })
    }

    private fun parse(sbn: StatusBarNotification): NavInfo {
        val n = sbn.notification
        val e = n.extras
        fun s(key: String) = e.getCharSequence(key)?.toString()?.trim() ?: ""
        val title = s(Notification.EXTRA_TITLE).ifBlank { s(Notification.EXTRA_TITLE_BIG) }
        val text = s(Notification.EXTRA_TEXT).ifBlank { s(Notification.EXTRA_BIG_TEXT) }
        val sub = s(Notification.EXTRA_SUB_TEXT).ifBlank { s(Notification.EXTRA_INFO_TEXT) }
        val icon = try {
            (n.getLargeIcon() ?: n.smallIcon)?.loadDrawable(this)?.let { toBitmap(it) }
        } catch (ex: Exception) { null }
        return NavInfo(title.ifBlank { "Navigation" }, text, sub, icon)
    }

    private fun toBitmap(d: Drawable): Bitmap {
        val w = maxOf(d.intrinsicWidth, 1); val h = maxOf(d.intrinsicHeight, 1)
        val k = minOf(1f, 128f / maxOf(w, h))
        val bw = maxOf((w * k).toInt(), 1); val bh = maxOf((h * k).toInt(), 1)
        val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, bw, bh); d.draw(Canvas(b))
        return b
    }
}
