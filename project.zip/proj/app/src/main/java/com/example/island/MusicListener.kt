package com.example.island

import android.service.notification.NotificationListenerService

// Sert uniquement à obtenir l'autorisation de lire les lecteurs de musique actifs.
class MusicListener : NotificationListenerService()
