package com.example.island

import android.app.Notification
import android.app.PendingIntent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class NavInfo(val title: String, val text: String, val sub: String, val icon: Bitmap?)
data class CallInfo(
    val name: String, val status: String, val since: Long, val icon: Bitmap?,
    val hangup: PendingIntent?, val answer: PendingIntent?
)
data class RecInfo(val label: String, val since: Long, val stop: PendingIntent?)

/** Pont entre le service d'écoute des notifications et l'îlot. */
object Bridge {
    var nav: NavInfo? = null
    var call: CallInfo? = null
    var rec: RecInfo? = null
    var clockEnd: Long = 0L          // fin du minuteur de l'appli Horloge (ms, horloge murale)
    var listener: (() -> Unit)? = null
    fun changed() { listener?.invoke() }
}

/**
 * Sert à lire les lecteurs de musique (autorisation) et les notifications :
 * navigation Google Maps, appels, enregistrements, minuteur de l'appli Horloge.
 */
class MusicListener : NotificationListenerService() {
    private val maps = "com.google.android.apps.maps"

    override fun onListenerConnected() { scanAll() }
    override fun onNotificationPosted(sbn: StatusBarNotification) { scanAll() }
    override fun onNotificationRemoved(sbn: StatusBarNotification) { scanAll() }

    private fun scanAll() {
        val all: List<StatusBarNotification> =
            try { activeNotifications?.toList() } catch (e: Exception) { null } ?: return

        val navList = all.filter { it.packageName == maps }
        val navSbn = navList.firstOrNull { it.notification.category == Notification.CATEGORY_NAVIGATION }
            ?: navList.firstOrNull { it.isOngoing }

        val callList = all.filter { it.notification.category == Notification.CATEGORY_CALL }
        val callSbn = callList.firstOrNull { it.isOngoing } ?: callList.firstOrNull()

        val recSbn = all.firstOrNull {
            it.packageName != maps && it.packageName != packageName &&
                it.notification.category != Notification.CATEGORY_CALL && it.isOngoing && looksLikeRecording(it)
        }
        val clockEnd = all.firstNotNullOfOrNull { clockTimerEnd(it) } ?: 0L

        Bridge.nav = navSbn?.let { parseNav(it) }
        Bridge.call = callSbn?.let { parseCall(it) }
        Bridge.rec = recSbn?.let { parseRec(it) }
        Bridge.clockEnd = clockEnd
        Bridge.changed()
    }

    private fun str(n: Notification, key: String) =
        n.extras.getCharSequence(key)?.toString()?.trim().orEmpty()

    private fun icon(n: Notification): Bitmap? = try {
        (n.getLargeIcon() ?: n.smallIcon)?.loadDrawable(this)?.let { toBitmap(it) }
    } catch (ex: Exception) { null }

    private fun findAction(n: Notification, keys: List<String>): PendingIntent? =
        n.actions?.firstOrNull { a ->
            val t = a.title?.toString()?.lowercase() ?: ""
            keys.any { t.contains(it) }
        }?.actionIntent

    // ----- navigation -----
    private fun parseNav(sbn: StatusBarNotification): NavInfo {
        val n = sbn.notification
        val title = str(n, Notification.EXTRA_TITLE).ifBlank { str(n, Notification.EXTRA_TITLE_BIG) }
        val text = str(n, Notification.EXTRA_TEXT).ifBlank { str(n, Notification.EXTRA_BIG_TEXT) }
        val sub = str(n, Notification.EXTRA_SUB_TEXT).ifBlank { str(n, Notification.EXTRA_INFO_TEXT) }
        return NavInfo(title.ifBlank { "Navigation" }, text, sub, icon(n))
    }

    // ----- appels -----
    private fun parseCall(sbn: StatusBarNotification): CallInfo {
        val n = sbn.notification
        val since = if (n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)) n.`when` else 0L
        val answer = findAction(n, listOf("répond", "repond", "answer", "accept", "décroch", "decroch"))
        val hang = findAction(n, listOf("raccroch", "hang", "end", "terminer", "refus", "decline", "reject", "dismiss"))
        return CallInfo(str(n, Notification.EXTRA_TITLE).ifBlank { "Appel" },
            str(n, Notification.EXTRA_TEXT), since, icon(n), hang, answer)
    }

    // ----- enregistrements (écran ou dictaphone) -----
    private fun looksLikeRecording(sbn: StatusBarNotification): Boolean {
        val n = sbn.notification
        val t = (str(n, Notification.EXTRA_TITLE) + " " + str(n, Notification.EXTRA_TEXT) + " " +
            str(n, Notification.EXTRA_SUB_TEXT)).lowercase()
        return t.contains("enregistr") || t.contains("record")
    }

    private fun parseRec(sbn: StatusBarNotification): RecInfo {
        val n = sbn.notification
        val since = if (n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)) n.`when` else 0L
        val title = str(n, Notification.EXTRA_TITLE).ifBlank { "Enregistrement" }
        val stop = findAction(n, listOf("arrêt", "arret", "stop", "terminer", "fin"))
        return RecInfo(title, since, stop)
    }

    // ----- minuteur de l'appli Horloge -----
    private fun clockTimerEnd(sbn: StatusBarNotification): Long? {
        if (!sbn.packageName.contains("clock", ignoreCase = true)) return null
        val n = sbn.notification
        val e = n.extras
        if (e.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER) &&
            e.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN) &&
            n.`when` > System.currentTimeMillis()) return n.`when`
        val txt = (str(n, Notification.EXTRA_TITLE) + " " + str(n, Notification.EXTRA_TEXT)).lowercase()
        if (txt.contains("minuteur") || txt.contains("timer")) {
            val m = Regex("(\\d{1,2}):(\\d{2})(?::(\\d{2}))?").find(txt) ?: return null
            val a = m.groupValues[1].toLong(); val b = m.groupValues[2].toLong()
            val c = m.groupValues[3].toLongOrNull()
            val secs = if (c != null) a * 3600 + b * 60 + c else a * 60 + b
            if (secs > 0) return System.currentTimeMillis() + secs * 1000
        }
        return null
    }

    private fun toBitmap(d: Drawable): Bitmap {
        val w = maxOf(d.intrinsicWidth, 1); val h = maxOf(d.intrinsicHeight, 1)
        val k = minOf(1f, 128f / maxOf(w, h))
        val bw = maxOf((w * k).toInt(), 1); val bh = maxOf((h * k).toInt(), 1)
        val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, bw, bh); d.draw(Canvas(b))
        return b
    }
}
