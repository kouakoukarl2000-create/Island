package com.example.island

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class IslandService : Service() {
    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private lateinit var pill: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var clockBox: LinearLayout
    private lateinit var musicBox: LinearLayout
    private lateinit var mini: TextView
    private lateinit var musicTitle: TextView
    private lateinit var musicArtist: TextView
    private lateinit var btnPlay: TextView
    private val bg = GradientDrawable().apply { setColor(Color.BLACK) }
    private val handler = Handler(Looper.getMainLooper())
    private var expanded = false

    // Musique
    private var controller: MediaController? = null
    private var playing = false
    private var hasMusic = false

    // Réglages : tailles en dp et distance depuis le haut de l'écran
    private val idleW = 120; private val musicW = 200; private val smallH = 35
    private val bigW = 320;  private val bigH = 130
    private val topOffset = 8

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (root == null) addIsland()
        setupMusic()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "Dynamic Island", NotificationManager.IMPORTANCE_MIN))
        val n: Notification = NotificationCompat.Builder(this, "island")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Dynamic Island active")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
        }

    private fun addIsland() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        // Horloge (quand aucune musique)
        clockBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(TextClock(context).apply {
                format12Hour = "h:mm"; format24Hour = "HH:mm"
                textSize = 34f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            })
            addView(TextClock(context).apply {
                format12Hour = "EEEE d MMMM"; format24Hour = "EEEE d MMMM"
                textSize = 13f; setTextColor(Color.parseColor("#9A9AA6")); gravity = Gravity.CENTER
            })
        }

        // Lecteur (quand une musique joue)
        musicTitle = label("", 15f, Color.WHITE, true)
        musicArtist = label("", 12f, Color.parseColor("#9A9AA6"))
        val prev = label("⏮", 26f, Color.WHITE).apply {
            setPadding(dp(14), dp(2), dp(14), dp(2))
            setOnClickListener { controller?.transportControls?.skipToPrevious() }
        }
        btnPlay = label("⏸", 26f, Color.WHITE).apply {
            setPadding(dp(14), dp(2), dp(14), dp(2))
            setOnClickListener {
                if (playing) controller?.transportControls?.pause()
                else controller?.transportControls?.play()
            }
        }
        val next = label("⏭", 26f, Color.WHITE).apply {
            setPadding(dp(14), dp(2), dp(14), dp(2))
            setOnClickListener { controller?.transportControls?.skipToNext() }
        }
        musicBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(6), dp(16), dp(6))
            visibility = View.GONE
            addView(musicTitle); addView(musicArtist)
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER
                addView(prev); addView(btnPlay); addView(next)
            })
        }

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            alpha = 0f
            addView(clockBox); addView(musicBox)
        }

        // Texte du mode réduit (musique en cours)
        mini = label("", 13f, Color.WHITE, true).apply {
            setPadding(dp(14), 0, dp(14), 0)
            visibility = View.GONE
        }

        pill = FrameLayout(this).apply {
            background = bg
            addView(content, FrameLayout.LayoutParams(-1, -1))
            addView(mini, FrameLayout.LayoutParams(-1, -1))
            layoutParams = FrameLayout.LayoutParams(dp(idleW), dp(smallH))
            setOnClickListener { toggle() }
        }
        bg.cornerRadius = dp(smallH) / 2f

        root = FrameLayout(this).apply { addView(pill) }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(topOffset)
        }
        wm.addView(root, lp)
    }

    // ---------- Musique ----------
    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = refresh()
        override fun onMetadataChanged(metadata: MediaMetadata?) = refresh()
    }
    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private fun setupMusic() {
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(this, MusicListener::class.java)
            msm.removeOnActiveSessionsChangedListener(sessionsListener)
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            pick(msm.getActiveSessions(cn))
        } catch (e: SecurityException) {
            // Accès aux notifications pas encore autorisé : l'îlot reste en mode horloge
        }
    }

    private fun pick(list: List<MediaController>?) {
        controller?.unregisterCallback(callback)
        controller = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        controller?.registerCallback(callback)
        refresh()
    }

    private fun refresh() {
        handler.post {
            val c = controller
            val st = c?.playbackState?.state
            playing = st == PlaybackState.STATE_PLAYING
            val md = c?.metadata
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
            hasMusic = title != null && (playing || st == PlaybackState.STATE_PAUSED)
            musicTitle.text = title ?: ""
            musicArtist.text = artist
            mini.text = "♪  " + (title ?: "")
            btnPlay.text = if (playing) "⏸" else "▶"
            clockBox.visibility = if (hasMusic) View.GONE else View.VISIBLE
            musicBox.visibility = if (hasMusic) View.VISIBLE else View.GONE
            mini.visibility = if (hasMusic && !expanded) View.VISIBLE else View.GONE
            animateToTarget()
        }
    }

    // ---------- Animation ----------
    private fun animateToTarget() {
        val w1 = dp(if (expanded) bigW else if (hasMusic) musicW else idleW)
        val h1 = dp(if (expanded) bigH else smallH)
        val w0 = pill.layoutParams.width; val h0 = pill.layoutParams.height
        if (w0 == w1 && h0 == h1) return
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450
            interpolator = OvershootInterpolator(1.1f)
            addUpdateListener {
                val f = it.animatedValue as Float
                val w = (w0 + (w1 - w0) * f).toInt()
                val h = (h0 + (h1 - h0) * f).toInt()
                pill.layoutParams = FrameLayout.LayoutParams(w, h)
                bg.cornerRadius = minOf(h / 2f, dp(34).toFloat())
            }
            start()
        }
    }

    private fun toggle() {
        expanded = !expanded
        handler.removeCallbacksAndMessages(null)
        mini.visibility = if (hasMusic && !expanded) View.VISIBLE else View.GONE
        animateToTarget()
        content.animate().alpha(if (expanded) 1f else 0f)
            .setStartDelay(if (expanded) 150 else 0).setDuration(250).start()
        if (expanded) handler.postDelayed({ if (expanded) toggle() }, 6000)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            getSystemService(MediaSessionManager::class.java)
                .removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {}
        controller?.unregisterCallback(callback)
        root?.let { wm.removeView(it) }
        root = null
        super.onDestroy()
    }
}
