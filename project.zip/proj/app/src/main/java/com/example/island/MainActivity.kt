package com.example.island

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Typeface
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("island", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun title(t: String, size: Float = 14f) = TextView(this).apply {
            text = t; textSize = size
            setPadding(0, pad / 2, 0, pad / 4)
        }.also { col.addView(it) }

        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { f() }
        }.also { col.addView(it) }

        fun slider(name: String, key: String, lo: Int, hi: Int, def: Int, unit: String) {
            val tv = TextView(this).apply { setPadding(0, pad / 2, 0, 0) }
            fun show(v: Int) { tv.text = "$name : $v$unit" }
            show(prefs.getInt(key, def))
            col.addView(tv)
            col.addView(SeekBar(this).apply {
                this.max = hi - lo
                progress = prefs.getInt(key, def) - lo
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        val v = p + lo
                        show(v)
                        if (fromUser) prefs.edit().putInt(key, v).apply()
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            })
        }

        title("Dynamic Island", 24f)
        btn("1. Autoriser l'affichage par-dessus les apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("1b. Autoriser la musique (accès aux notifications)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        btn("2. Afficher l'îlot") {
            if (Settings.canDrawOverlays(this))
                startForegroundService(Intent(this, IslandService::class.java))
        }
        btn("Masquer l'îlot") { stopService(Intent(this, IslandService::class.java)) }
        btn("Lancer un minuteur de 60 s") {
            if (Settings.canDrawOverlays(this))
                startForegroundService(Intent(this, IslandService::class.java)
                    .setAction(IslandService.ACTION_TIMER).putExtra("sec", 60))
        }

        btn("Autoriser « raccrocher » (appels)") {
            requestPermissions(arrayOf(Manifest.permission.ANSWER_PHONE_CALLS), 1)
        }
        btn("Diagnostic : voir les notifications") {
            val txt = MusicListener.instance?.dump()
                ?: "L'accès aux notifications n'est pas actif (bouton 1b)."
            val tv = TextView(this).apply {
                text = txt; textSize = 11f; typeface = Typeface.MONOSPACE
                setTextIsSelectable(true); setPadding(pad, pad, pad, pad)
            }
            AlertDialog.Builder(this)
                .setTitle("Notifications actives")
                .setView(ScrollView(this).apply { addView(tv) })
                .setPositiveButton("Fermer", null)
                .setNeutralButton("Copier") { _, _ ->
                    getSystemService(ClipboardManager::class.java)
                        .setPrimaryClip(ClipData.newPlainText("diagnostic", txt))
                }
                .show()
        }

        title("Taille et position (se règle en direct)", 16f)
        slider("Taille", "scale", 60, 180, 100, " %")
        slider("Distance du haut", "top", 0, 80, 8, " dp")
        slider("Décalage gauche / droite", "x", -300, 300, 0, " dp")
        btn("Réinitialiser") {
            prefs.edit().clear().apply()
            recreate()
        }

        setContentView(ScrollView(this).apply { addView(col) })
    }
}
