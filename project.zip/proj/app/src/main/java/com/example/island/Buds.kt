package com.example.island

import android.Manifest
import android.animation.ValueAnimator
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import androidx.core.content.ContextCompat
import java.util.UUID

/** Niveaux de batterie connus (-1 = inconnu). */
class BudsInfo {
    var left = -1
    var right = -1
    var caseLvl = -1
    var single = -1
}

/**
 * Surveille la connexion des Galaxy Buds2 Pro (et d'eux seulement) et lit leur batterie.
 * - connexion / déconnexion : événements Bluetooth du système ;
 * - batterie globale : valeur donnée par Android, si elle existe ;
 * - batterie gauche / droite / étui : lecture expérimentale du canal propre à Samsung.
 */
class BudsMonitor(private val ctx: Context, private val handler: Handler, private val cb: Callback) {
    interface Callback {
        fun onBudsConnected()
        fun onBudsDisconnected()
        fun onBudsInfo()
    }

    companion object {
        const val ADDRESS = "41:42:FF:63:CE:F2"
        private val SPP: UUID = UUID.fromString("2e73a4ad-332d-41fc-90e2-16bef06523f2")
        private const val BATTERY_ACTION = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
        private const val BATTERY_EXTRA = "android.bluetooth.device.extra.BATTERY_LEVEL"
        private val logBuf = StringBuilder()

        @Synchronized
        fun log(s: String) {
            logBuf.append(s).append('\n')
            if (logBuf.length > 8000) logBuf.delete(0, logBuf.length - 6000)
        }

        @Synchronized
        fun dumpLog(): String =
            if (logBuf.isEmpty()) "Aucun événement Bluetooth reçu pour l'instant." else logBuf.toString()
    }

    val info = BudsInfo()
    var detailed = false
    private var receiver: BroadcastReceiver? = null
    private var device: BluetoothDevice? = null
    private var sppThread: Thread? = null
    private var socket: BluetoothSocket? = null
    private var pend = ByteArray(0)

    private fun hasPerm() = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    @Suppress("DEPRECATION")
    private fun deviceOf(i: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33)
            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)

    private fun isBuds(d: BluetoothDevice?): Boolean {
        if (d == null) return false
        if (d.address.equals(ADDRESS, ignoreCase = true)) return true
        val n = try { if (hasPerm()) d.name else null } catch (e: SecurityException) { null }
        return n != null && n.lowercase().replace(" ", "").contains("buds2pro")
    }

    fun start() {
        if (receiver != null) return
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val d = deviceOf(i)
                when (i.action) {
                    BluetoothDevice.ACTION_ACL_CONNECTED -> if (d != null && isBuds(d)) onConnected(d)
                    BluetoothDevice.ACTION_ACL_DISCONNECTED -> if (isBuds(d)) onDisconnected()
                    BATTERY_ACTION -> if (isBuds(d)) {
                        val lvl = i.getIntExtra(BATTERY_EXTRA, -1)
                        log("Batterie (système) : $lvl")
                        if (lvl in 0..100) { info.single = lvl; cb.onBudsInfo() }
                    }
                }
            }
        }
        val f = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(BATTERY_ACTION)
        }
        ContextCompat.registerReceiver(ctx, r, f, ContextCompat.RECEIVER_EXPORTED)
        receiver = r
        log("Surveillance Bluetooth démarrée (autorisation : " + hasPerm() + ")")
    }

    fun stop() {
        receiver?.let { try { ctx.unregisterReceiver(it) } catch (_: Exception) {} }
        receiver = null
        stopSpp()
    }

    private fun onConnected(d: BluetoothDevice) {
        device = d
        info.left = -1; info.right = -1; info.caseLvl = -1; info.single = -1
        log("Galaxy Buds2 Pro connectés")
        cb.onBudsConnected()
        for (delay in longArrayOf(1500L, 5000L, 12000L)) handler.postDelayed({ readSystemBattery() }, delay)
        if (detailed) handler.postDelayed({ startSpp(d) }, 1200L)
    }

    private fun onDisconnected() {
        log("Galaxy Buds2 Pro déconnectés")
        stopSpp()
        device = null
        cb.onBudsDisconnected()
    }

    private fun readSystemBattery() {
        val d = device ?: return
        if (!hasPerm()) return
        try {
            val v = d.javaClass.getMethod("getBatteryLevel").invoke(d) as? Int
            log("getBatteryLevel = $v")
            if (v != null && v in 0..100) { info.single = v; cb.onBudsInfo() }
        } catch (e: Exception) {
            log("getBatteryLevel indisponible : " + e.javaClass.simpleName)
        }
    }

    // ----- canal propre à Samsung (expérimental) -----
    private fun startSpp(d: BluetoothDevice) {
        stopSpp()
        if (!hasPerm()) return
        val t = Thread {
            try {
                BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
                val sock = d.createRfcommSocketToServiceRecord(SPP)
                socket = sock
                sock.connect()
                log("Canal Samsung ouvert")
                val ins = sock.inputStream
                val buf = ByteArray(1024)
                while (!Thread.currentThread().isInterrupted) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    feed(buf, n)
                }
                log("Canal Samsung fermé")
            } catch (e: Exception) {
                log("Canal Samsung : " + (e.message ?: e.javaClass.simpleName))
            }
        }
        t.isDaemon = true
        sppThread = t
        t.start()
    }

    private fun stopSpp() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        sppThread?.interrupt()
        sppThread = null
        pend = ByteArray(0)
    }

    private fun hex(b: ByteArray, n: Int = b.size) = (0 until n).joinToString(" ") { "%02X".format(b[it]) }

    private fun feed(b: ByteArray, n: Int) {
        log("RX " + hex(b, n))
        pend += b.copyOf(n)
        while (true) {
            val s = pend.indexOf(0xFD.toByte())
            if (s < 0) { pend = ByteArray(0); return }
            if (s > 0) pend = pend.copyOfRange(s, pend.size)
            if (pend.size < 4) return
            val size = ((pend[1].toInt() and 0xFF) or ((pend[2].toInt() and 0xFF) shl 8)) and 0x3FF
            val total = 1 + 2 + size + 1
            if (size < 3 || total > 2048) { pend = pend.copyOfRange(1, pend.size); continue }
            if (pend.size < total) return
            val id = pend[3].toInt() and 0xFF
            val payload = pend.copyOfRange(4, 4 + size - 3)
            pend = pend.copyOfRange(total, pend.size)
            handleMsg(id, payload)
        }
    }

    private fun handleMsg(id: Int, p: ByteArray) {
        log("Message 0x%02X : %s".format(id, hex(p)))
        if ((id == 0x60 || id == 0x61) && p.size >= 8) {
            fun ok(v: Int) = if (v in 0..100) v else -1
            val l = ok(p[2].toInt() and 0xFF)
            val r = ok(p[3].toInt() and 0xFF)
            val c = ok(p[7].toInt() and 0xFF)
            if (l >= 0 || r >= 0 || c >= 0) {
                info.left = l; info.right = r; info.caseLvl = c
                handler.post { cb.onBudsInfo() }
            }
        }
    }
}

/**
 * Animation : l'étui blanc s'ouvre et les écouteurs blancs (grille du micro sombre, embout gris) en sortent.
 * which : 0 les deux, 1 gauche seul, 2 droit seul.
 */
class BudsView(c: Context) : View(c) {
    var which = 0
        set(v) { field = v; invalidate() }
    private var t = 0f
    private var anim: ValueAnimator? = null
    private val d = c.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    private val over = OvershootInterpolator(1.8f)

    /** open = true : les écouteurs sortent ; false : ils rentrent. */
    fun play(open: Boolean) {
        anim?.cancel()
        val from = if (open) 0f else t
        val to = if (open) 1f else 0f
        anim = ValueAnimator.ofFloat(from, to).apply {
            duration = if (open) 1400L else 800L
            interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun seg(a: Float, b: Float) = ((t - a) / (b - a)).coerceIn(0f, 1f)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cw = w * 0.84f; val ch = h * 0.40f
        val cl = (w - cw) / 2f; val ct = h - ch - h * 0.03f

        // 1) couvercle : il se relève derrière l'étui, intérieur blanc avec deux creux
        val k = 1f - seg(0f, 0.30f)
        val e = 1f - k * k
        val lidH0 = ch * 0.45f
        val lidTop = ct - (lidH0 + (ch * 0.95f - lidH0) * e)
        val lidBottom = ct - e * ch * 0.10f
        paint.shader = LinearGradient(0f, lidTop, 0f, lidBottom,
            0xFFF4F4F7.toInt(), 0xFFD9D9DF.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(cl + cw * 0.02f, lidTop, cl + cw * 0.98f, lidBottom), ch * 0.40f, ch * 0.40f, paint)
        paint.shader = null
        if (e > 0.3f) {
            paint.color = ((e * 255).toInt() shl 24) or 0xD0D0D6
            val ry = (lidBottom - lidTop) * 0.22f
            c.drawOval(RectF(cl + cw * 0.18f, lidTop + ry * 0.9f, cl + cw * 0.46f, lidTop + ry * 2.6f), paint)
            c.drawOval(RectF(cl + cw * 0.54f, lidTop + ry * 0.9f, cl + cw * 0.82f, lidTop + ry * 2.6f), paint)
        }

        // 2) les écouteurs (blanc, grille du micro sombre, embout gris côté intérieur)
        val bw = cw * 0.25f; val bh = bw * 1.10f
        fun bud(cx: Float, mirror: Boolean, p: Float) {
            val ee = over.getInterpolation(p)
            val y0 = ct + ch * 0.30f
            val y1 = ct - bh * 0.85f
            val top = y0 + (y1 - y0) * ee
            c.save()
            if (mirror) c.scale(-1f, 1f, cx, top + bh / 2f)
            c.rotate(-14f * p, cx, top + bh / 2f)
            val x0 = cx - bw / 2f
            // buse et embout en silicone
            paint.color = 0xFF8E8E93.toInt()
            c.drawRoundRect(RectF(x0 + bw * 0.86f, top + bh * 0.34f, x0 + bw * 1.14f, top + bh * 0.62f), bw * 0.08f, bw * 0.08f, paint)
            paint.color = 0xFFCFCFD4.toInt()
            c.drawOval(RectF(x0 + bw * 0.98f, top + bh * 0.22f, x0 + bw * 1.34f, top + bh * 0.74f), paint)
            paint.color = 0xFFA9A9AF.toInt()
            c.drawOval(RectF(x0 + bw * 1.04f, top + bh * 0.32f, x0 + bw * 1.18f, top + bh * 0.64f), paint)
            // corps blanc
            paint.shader = RadialGradient(x0 + bw * 0.38f, top + bh * 0.30f, bw * 0.95f,
                0xFFFFFFFF.toInt(), 0xFFDCDCE2.toInt(), Shader.TileMode.CLAMP)
            c.drawOval(RectF(x0, top, x0 + bw, top + bh), paint)
            paint.shader = null
            // grille du micro
            paint.color = 0xFF55555B.toInt()
            c.drawRoundRect(RectF(x0 + bw * 0.14f, top + bh * 0.14f, x0 + bw * 0.52f, top + bh * 0.30f), bw * 0.09f, bw * 0.09f, paint)
            // petite fente (évent)
            paint.color = 0xFFC9C9CE.toInt()
            c.drawRoundRect(RectF(x0 + bw * 0.30f, top + bh * 0.70f, x0 + bw * 0.52f, top + bh * 0.78f), bw * 0.04f, bw * 0.04f, paint)
            c.restore()
        }
        val pL = seg(0.22f, 0.80f); val pR = seg(0.30f, 0.88f)
        when (which) {
            1 -> bud(w / 2f, false, pL)
            2 -> bud(w / 2f, true, pL)
            else -> { bud(w / 2f - cw * 0.27f, false, pL); bud(w / 2f + cw * 0.27f, true, pR) }
        }

        // 3) face avant de l'étui (blanc), qui cache le bas des écouteurs
        paint.shader = LinearGradient(0f, ct, 0f, ct + ch,
            0xFFFFFFFF.toInt(), 0xFFDDDDE3.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(cl, ct, cl + cw, ct + ch), ch * 0.42f, ch * 0.42f, paint)
        paint.shader = null
        paint.color = 0xFFCBCBD1.toInt()
        c.drawRect(cl + ch * 0.28f, ct + ch * 0.03f, cl + cw - ch * 0.28f, ct + ch * 0.06f, paint)
        paint.color = if (e > 0.5f) 0xFF30D158.toInt() else 0xFFB4B4BA.toInt()
        c.drawCircle(cl + cw * 0.5f, ct + ch * 0.66f, ch * 0.07f, paint)

        // 4) pastille L ou R quand un seul écouteur est concerné
        if (which != 0) {
            val a = seg(0.6f, 0.9f)
            if (a > 0f) {
                val cx = w / 2f + bw * 0.95f; val cy = ct - bh * 0.85f
                paint.color = ((255 * a).toInt() shl 24) or 0x30D158
                c.drawCircle(cx, cy, 9f * d, paint)
                txt.color = ((255 * a).toInt() shl 24) or 0x000000
                txt.textSize = 11f * d
                c.drawText(if (which == 1) "L" else "R", cx, cy + 4f * d, txt)
            }
        }
    }

    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }
}
