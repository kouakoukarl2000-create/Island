package com.example.island

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.ActivityOptions
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.hardware.camera2.CameraManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.telecom.TelecomManager
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs
import kotlin.math.sin

/** Égaliseur animé (4 barres). */
class EqView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FF375F") }
    private var phase = 0f
    private val anim = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 900; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }
    private var active = false
    fun setColor(c: Int) { p.color = c; invalidate() }
    fun setActive(a: Boolean) {
        if (a == active) return
        active = a
        if (a) anim.start() else { anim.cancel(); invalidate() }
    }
    override fun onDraw(canvas: Canvas) {
        val n = 4; val bw = width / (n * 2 - 1f)
        for (i in 0 until n) {
            val f = if (active) 0.25f + 0.75f * abs(sin(phase + i * 1.1f)) else 0.25f
            val h = height * f; val x = i * bw * 2
            canvas.drawRoundRect(RectF(x, (height - h) / 2, x + bw, (height + h) / 2), bw / 2, bw / 2, p)
        }
    }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
}

/** Point qui pulse (enregistrement). */
class PulseDot(c: Context, col: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col }
    private val anim = ValueAnimator.ofFloat(0.35f, 1f).apply {
        duration = 700; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
        addUpdateListener { p.alpha = (255 * (it.animatedValue as Float)).toInt(); invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) { c.drawCircle(width / 2f, height / 2f, minOf(width, height) / 2f, p) }
}

/** Barre de progression fine. */
class ProgressView(c: Context) : View(c) {
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#44FFFFFF") }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    var progress = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    override fun onDraw(canvas: Canvas) {
        val r = height / 2f
        canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), r, r, track)
        canvas.drawRoundRect(RectF(0f, 0f, width * progress, height.toFloat()), r, r, fill)
    }
}

/** Icônes de lecture : 0 précédent, 1 lecture, 2 pause, 3 suivant. */
class IconView(c: Context, private var kind: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.FILL_AND_STROKE
        strokeJoin = Paint.Join.ROUND; strokeWidth = 3f
    }
    private var off = 0f

    /** Pop quand l'icône change (pause <-> lecture). */
    fun set(k: Int) {
        if (k == kind) return
        kind = k; invalidate()
        scaleX = 0.55f; scaleY = 0.55f
        animate().scaleX(1f).scaleY(1f).setDuration(380)
            .setInterpolator(OvershootInterpolator(2.2f)).start()
    }

    /** Petit coup de côté avec rebond (précédent / suivant). */
    fun nudge(dir: Int, dist: Float) {
        val a = ValueAnimator.ofFloat(off, dir * dist).apply {
            duration = 80
            addUpdateListener { off = it.animatedValue as Float; invalidate() }
        }
        val b = ValueAnimator.ofFloat(dir * dist, 0f).apply {
            duration = 360; interpolator = OvershootInterpolator(3f)
            addUpdateListener { off = it.animatedValue as Float; invalidate() }
        }
        AnimatorSet().apply { playSequentially(a, b); start() }
    }

    override fun onDraw(c: Canvas) {
        val sv = c.save()
        c.translate(off, 0f)
        val cx = width / 2f; val cy = height / 2f; val s = minOf(width, height) * 0.26f
        val path = Path()
        when (kind) {
            0 -> {
                c.drawRoundRect(RectF(cx - s, cy - s, cx - s * 0.6f, cy + s), 2f, 2f, p)
                path.moveTo(cx + s, cy - s); path.lineTo(cx + s, cy + s); path.lineTo(cx - s * 0.45f, cy)
                path.close(); c.drawPath(path, p)
            }
            1 -> {
                path.moveTo(cx - s * 0.8f, cy - s); path.lineTo(cx - s * 0.8f, cy + s); path.lineTo(cx + s, cy)
                path.close(); c.drawPath(path, p)
            }
            2 -> {
                c.drawRoundRect(RectF(cx - s * 0.8f, cy - s, cx - s * 0.2f, cy + s), 2f, 2f, p)
                c.drawRoundRect(RectF(cx + s * 0.2f, cy - s, cx + s * 0.8f, cy + s), 2f, 2f, p)
            }
            else -> {
                c.drawRoundRect(RectF(cx + s * 0.6f, cy - s, cx + s, cy + s), 2f, 2f, p)
                path.moveTo(cx - s, cy - s); path.lineTo(cx - s, cy + s); path.lineTo(cx + s * 0.45f, cy)
                path.close(); c.drawPath(path, p)
            }
        }
        c.restoreToCount(sv)
    }
}

/** Petite batterie pour l'état « en charge ».  pour l'état « en charge ». */
class BatteryView(c: Context) : View(c) {
    var level = 80
        set(v) { field = v.coerceIn(0, 100); invalidate() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 4f
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#30D158") }
    private val tip = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    var fillColor = Color.parseColor("#30D158")
        set(v) { field = v; fill.color = v; invalidate() }

    /** Le niveau se remplit en animation. */
    fun animateTo(target: Int) {
        ValueAnimator.ofInt(0, target.coerceIn(0, 100)).apply {
            duration = 800; interpolator = DecelerateInterpolator()
            addUpdateListener { level = it.animatedValue as Int }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width - 8f; val h = height.toFloat()
        c.drawRoundRect(RectF(2f, 2f, w - 2f, h - 2f), h * 0.3f, h * 0.3f, stroke)
        c.drawRoundRect(RectF(7f, 7f, 7f + (w - 14f) * level / 100f, h - 7f), h * 0.15f, h * 0.15f, fill)
        c.drawRoundRect(RectF(w, h * 0.35f, w + 5f, h * 0.65f), 2f, 2f, tip)
    }
}

/** Petit point de couleur (micro / caméra). */
class Dot(c: Context, col: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col }
    override fun onDraw(c: Canvas) { c.drawCircle(width / 2f, height / 2f, minOf(width, height) / 2f, p) }
}

/**
 * La pilule noire. Elle DESSINE elle-même sa forme animée (aucun re-calcul de mise en page
 * pendant l'animation) et découpe son contenu à cette forme : c'est ce qui la rend fluide.
 */
class IslandPill(c: Context) : FrameLayout(c) {
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val path = Path()
    private val rect = RectF()
    var pw = 0f
        private set
    var ph = 0f
        private set
    var maxRadius = 0f
    var onTap: (() -> Unit)? = null
    var onLong: (() -> Unit)? = null
    private var downInside = false
    private var longFired = false
    private var downX = 0f
    private var downY = 0f
    private val longRun = Runnable {
        longFired = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        onLong?.invoke()
    }

    init { setWillNotDraw(false) }

    fun setSize(w: Float, h: Float) { pw = w; ph = h; updateRect(); invalidate() }

    private fun updateRect() {
        val l = (width - pw) / 2f
        rect.set(l, 0f, l + pw, ph)
        val r = minOf(ph / 2f, maxRadius)
        path.reset(); path.addRoundRect(rect, r, r, Path.Direction.CW)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        pivotX = w / 2f; pivotY = 0f
        updateRect()
    }

    override fun dispatchDraw(canvas: Canvas) {
        canvas.drawPath(path, bgPaint)
        val save = canvas.save()
        canvas.clipPath(path)
        super.dispatchDraw(canvas)
        canvas.restoreToCount(save)
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN && !rect.contains(e.x, e.y)) return false
        return super.dispatchTouchEvent(e)
    }

    private fun release() {
        animate().scaleX(1f).scaleY(1f).setDuration(350)
            .setInterpolator(OvershootInterpolator(2.5f)).start()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downInside = rect.contains(e.x, e.y)
                if (!downInside) return false
                longFired = false; downX = e.x; downY = e.y
                postDelayed(longRun, ViewConfiguration.getLongPressTimeout().toLong())
                animate().scaleX(0.96f).scaleY(0.96f).setDuration(120)
                    .setInterpolator(LinearInterpolator()).start()
            }
            MotionEvent.ACTION_MOVE ->
                if (abs(e.x - downX) > 30 || abs(e.y - downY) > 30) removeCallbacks(longRun)
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun); release()
                if (downInside && !longFired && rect.contains(e.x, e.y)) onTap?.invoke()
            }
            MotionEvent.ACTION_CANCEL -> { removeCallbacks(longRun); release() }
        }
        return true
    }
}

class IslandService : Service() {
    companion object {
        const val ACTION_TIMER = "com.example.island.TIMER"
        const val ACTION_STOP_TIMER = "com.example.island.STOP_TIMER"
    }

    private enum class S { IDLE, MUSIC_S, MUSIC_L, TIMER_S, TIMER_L, CHARGE, HUD, NAV_S, NAV_L, CALL_S, CALL_L, REC_S, REC_L, BUDS }
    private enum class Act { CALL, REC, NAV, TIMER, MUSIC }

    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private var root: FrameLayout? = null
    private lateinit var pill: IslandPill
    private val handler = Handler(Looper.getMainLooper())

    // Réglages (modifiables depuis l'app)
    private var scale = 1f
    private var topDp = 8
    private var xDp = 0

    private val layers = mutableListOf<View>()
    private lateinit var vMusicS: View
    private lateinit var vMusicL: View
    private lateinit var vTimerS: View
    private lateinit var vTimerL: View
    private lateinit var vCharge: View
    private lateinit var vHud: View
    private lateinit var vNavS: View
    private lateinit var vNavL: View
    private lateinit var vCallS: View
    private lateinit var vCallL: View
    private lateinit var vRecS: View
    private lateinit var vRecL: View

    private lateinit var artS: ImageView
    private lateinit var artL: ImageView
    private lateinit var eqS: EqView
    private lateinit var eqL: EqView
    private lateinit var titleL: TextView
    private lateinit var artistL: TextView
    private lateinit var playIcon: IconView
    private lateinit var progressView: ProgressView
    private lateinit var tmS: TextView
    private lateinit var tmL: TextView
    private lateinit var stopTimerBtn: TextView
    private lateinit var batt: BatteryView
    private lateinit var chargeTxt: TextView
    private lateinit var hudEmoji: TextView
    private lateinit var hudLabel: TextView
    private lateinit var hudBar: ProgressView
    private lateinit var navArtS: ImageView
    private lateinit var navArtL: ImageView
    private lateinit var navTitleS: TextView
    private lateinit var navTitleL: TextView
    private lateinit var navTextL: TextView
    private lateinit var navSubL: TextView
    private lateinit var callArtS: ImageView
    private lateinit var callArtL: ImageView
    private lateinit var callDurS: TextView
    private lateinit var callNameL: TextView
    private lateinit var callStatusL: TextView
    private lateinit var btnAnswer: TextView
    private lateinit var recTimeS: TextView
    private lateinit var recTitleL: TextView
    private lateinit var recTimeL: TextView
    private lateinit var btnRecStop: TextView
    private lateinit var bubble: FrameLayout
    private lateinit var bubbleImg: ImageView
    private lateinit var bubbleTxt: TextView

    // États
    private var expanded = false
    private var controller: MediaController? = null
    private var playing = false
    private var hasMusic = false
    private var musicBmp: Bitmap? = null
    private var timerEnd = 0L
    private var timerExternal = false
    private var timerText = ""
    private var nav: NavInfo? = null
    private var call: CallInfo? = null
    private var rec: RecInfo? = null
    private var chargeShowing = false
    private var hudShowing = false
    private var pinned: Act? = null
    private var lastPrimary: Act? = null
    private var wantCallOpen = false
    private var bubbleShown = false
    private var receiverRegistered = false
    private var lastRinger = -1
    private var lastDnd = -1
    private var anim: ValueAnimator? = null
    private var tW = 0
    private var tH = 0
    private var showLock = false
    private var useDots = true
    private var useUnlock = true
    private lateinit var dotsRow: LinearLayout
    private lateinit var dotMic: Dot
    private lateinit var dotCam: Dot
    private lateinit var hudStatus: TextView
    private lateinit var chipMinus: TextView
    private lateinit var chipPlus: TextView
    private lateinit var timerPlay: IconView
    private var timerPaused = false
    private var timerLeftMs = 0L
    private val camBusy = mutableSetOf<String>()
    private var micOn = false
    private var privacyRegistered = false
    private var lastSaver = -1
    private var screenOnAt = 0L
    private var useBuds = true
    private var budsDetail = false
    private var budsMon: BudsMonitor? = null
    private var budsShowing = false
    private var budsConnected = false
    private lateinit var vBuds: View
    private lateinit var budsView: BudsView
    private lateinit var budsTitle: TextView
    private lateinit var budsLine: TextView
    private lateinit var boltTxt: TextView
    private lateinit var chargeLabel: TextView
    private var pulseAnim: ObjectAnimator? = null
    private var slideDir = 1
    private var lastTitle: String? = null
    private var lastArtist = ""
    private var lastBmp: Bitmap? = null
    private var shownTitle: String? = null
    private var hidePending = false
    private var lastWarn = Int.MAX_VALUE
    private var battFirst = true

    private fun dp(v: Int) = (v * resources.displayMetrics.density * scale).toInt()
    private fun dpa(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    // ---------- Cycle de vie ----------
    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("island", MODE_PRIVATE)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        Bridge.listener = { onBridge() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (root == null) { loadPrefs(); addIsland() }
        setupMusic()
        registerSystem()
        registerPrivacy()
        updateDots()
        startBuds()
        when (intent?.action) {
            ACTION_TIMER -> startTimer(intent?.getIntExtra("sec", 60) ?: 60)
            ACTION_STOP_TIMER -> stopTimer()
        }
        onBridge()
        return START_STICKY
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        handler.post {
            loadPrefs()
            when (key) {
                null, "scale", "lock" -> rebuild()
                "top", "x" -> updatePosition()
                "dots" -> updateDots()
                "buds", "budsDetail" -> startBuds()
                else -> {}
            }
        }
    }

    private fun loadPrefs() {
        scale = prefs.getInt("scale", 100) / 100f
        topDp = prefs.getInt("top", 8)
        xDp = prefs.getInt("x", 0)
        showLock = prefs.getInt("lock", 0) == 1
        useDots = prefs.getInt("dots", 1) == 1
        useUnlock = prefs.getInt("unlock", 1) == 1
        useBuds = prefs.getInt("buds", 1) == 1
        budsDetail = prefs.getInt("budsDetail", 0) == 1
    }

    private fun updatePosition() {
        val r = root ?: return
        val lp = r.layoutParams as? WindowManager.LayoutParams ?: return
        lp.y = dpa(topDp); lp.x = dpa(xDp)
        wm.updateViewLayout(r, lp)
    }

    private fun rebuild() {
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        addIsland()
        refresh()
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("island", "Dynamic Island", NotificationManager.IMPORTANCE_MIN))
        val n: Notification = NotificationCompat.Builder(this, "island")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Dynamic Island active")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ---------- Fabrication des vues ----------
    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text; textSize = size * scale; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END
        }

    private fun roundedArt(sizeDp: Int, radiusDp: Int) = ImageView(this).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#FF375F"), Color.parseColor("#5E5CE6")))
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dp(radiusDp).toFloat())
            }
        }
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    private fun navArt(sizeDp: Int, radiusDp: Int) = roundedArt(sizeDp, radiusDp).apply {
        setBackgroundColor(Color.parseColor("#0A84FF"))
        scaleType = ImageView.ScaleType.FIT_CENTER
        val p = dp(4); setPadding(p, p, p, p)
    }

    private fun callArt(sizeDp: Int) = roundedArt(sizeDp, sizeDp / 2).apply {
        setBackgroundColor(Color.parseColor("#5E5CE6"))
        scaleType = ImageView.ScaleType.FIT_CENTER
        val p = dp(sizeDp / 6); setPadding(p, p, p, p)
    }

    private fun roundBtn(t: String, color: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 18f * scale; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor(color)) }
        layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        pressEffect(this)
        setOnClickListener { onClick() }
    }

    /** Le bouton rétrécit quand on appuie et revient avec un petit rebond. */
    private fun pressEffect(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.82f).scaleY(0.82f).setDuration(90)
                        .setInterpolator(LinearInterpolator()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(320)
                        .setInterpolator(OvershootInterpolator(2.5f)).start()
            }
            false
        }
    }

    private fun icon(kind: Int, sizeDp: Int, dir: Int = 0, onClick: () -> Unit) = IconView(this, kind).apply {
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply {
            marginStart = dp(8); marginEnd = dp(8)
        }
        pressEffect(this)
        setOnClickListener {
            if (dir != 0) { slideDir = dir; nudge(dir, dpa(8).toFloat() * scale) }
            onClick()
        }
    }

    private fun spacer() = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) }

    private fun addLayer(v: View, s: S) {
        val (w, h) = sizeOf(s)
        pill.addView(v, FrameLayout.LayoutParams(dp(w), dp(h), Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        v.alpha = 0f; v.visibility = View.GONE
        layers.add(v)
    }

    private fun addIsland() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        layers.clear()
        val white = Color.WHITE; val grey = Color.parseColor("#9A9AA6")
        val orange = Color.parseColor("#FF9F0A"); val green = Color.parseColor("#30D158")
        val red = Color.parseColor("#FF453A")

        pill = IslandPill(this).apply {
            maxRadius = dp(38).toFloat()
            onTap = { toggle() }
            onLong = { openPrimaryApp() }
        }

        // --- Musique réduite ---
        artS = roundedArt(24, 7)
        eqS = EqView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(20), dp(16)) }
        vMusicS = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(16), 0)
            addView(artS); addView(spacer()); addView(eqS)
        }

        // --- Musique développée ---
        artL = roundedArt(56, 13)
        eqL = EqView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(22), dp(18)) }
        titleL = label("", 14f, white, true)
        artistL = label("", 12f, grey)
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12); marginEnd = dp(8) }
            addView(titleL); addView(artistL)
        }
        progressView = ProgressView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(10) }
        }
        playIcon = icon(2, 52) {
            if (playing) controller?.transportControls?.pause() else controller?.transportControls?.play()
        }
        vMusicL = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(6))
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(artL); addView(texts); addView(eqL)
            })
            addView(progressView)
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) }
                addView(icon(0, 44, -1) { controller?.transportControls?.skipToPrevious() })
                addView(playIcon)
                addView(icon(3, 44, 1) { controller?.transportControls?.skipToNext() })
            })
        }

        // --- Minuteur ---
        tmS = label("0:00", 14f, orange, true).apply { fontFeatureSettings = "tnum" }
        vTimerS = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(16), 0)
            addView(label("⏱", 15f, orange)); addView(spacer()); addView(tmS)
        }
        tmL = label("0:00", 38f, orange, true).apply { fontFeatureSettings = "tnum"; gravity = Gravity.CENTER }
        fun chip(t: String, bg: String, onClick: () -> Unit) = label(t, 13f, white, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = GradientDrawable().apply { setColor(Color.parseColor(bg)); cornerRadius = dp(16).toFloat() }
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(4); marginEnd = dp(4) }
            pressEffect(this)
            setOnClickListener { onClick() }
        }
        chipMinus = chip("−1 min", "#2C2C2E") { addTime(-60000L) }
        chipPlus = chip("+1 min", "#2C2C2E") { addTime(60000L) }
        stopTimerBtn = chip("Arrêter", "#FF453A") { stopTimer() }
        timerPlay = icon(2, 40) { toggleTimer() }
        vTimerL = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            addView(tmL)
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4) }
                addView(chipMinus); addView(timerPlay); addView(chipPlus); addView(stopTimerBtn)
            })
        }

        // --- En charge ---
        batt = BatteryView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(36), dp(18)) }
        chargeTxt = label("", 14f, green, true)
        boltTxt = label("⚡", 16f, green, true).apply { setPadding(dp(8), 0, 0, 0) }
        chargeLabel = label("  En charge", 14f, white, true)
        vCharge = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
            addView(batt); addView(boltTxt); addView(chargeLabel)
            addView(spacer()); addView(chargeTxt)
        }

        // --- Silencieux / volume / ne pas déranger ---
        hudEmoji = label("🔔", 20f, white)
        hudLabel = label("", 14f, white, true).apply { setPadding(dp(10), 0, 0, 0) }
        hudBar = ProgressView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(70), dp(5)) }
        hudStatus = label("", 13f, white, true).apply { visibility = View.GONE }
        vHud = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
            addView(hudEmoji); addView(hudLabel); addView(spacer()); addView(hudStatus); addView(hudBar)
        }

        // --- Appel ---
        callArtS = callArt(25)
        callDurS = label("", 13f, green, true).apply {
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) }
        }
        vCallS = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(16), 0)
            addView(callArtS); addView(callDurS)
        }
        callArtL = callArt(48)
        callNameL = label("", 16f, white, true)
        callStatusL = label("", 13f, grey)
        btnAnswer = roundBtn("✓", "#30D158") { call?.answer?.let { sendPI(it) } }
        val btnHang = roundBtn("✕", "#FF453A") { hangUp() }
        vCallL = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
            addView(callArtL)
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12); marginEnd = dp(8) }
                addView(callNameL); addView(callStatusL)
            })
            addView(btnAnswer, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(8) })
            addView(btnHang)
        }

        // --- Enregistrement ---
        recTimeS = label("0:00", 13f, red, true).apply { fontFeatureSettings = "tnum" }
        vRecS = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), 0, dp(16), 0)
            addView(PulseDot(context, red), LinearLayout.LayoutParams(dp(11), dp(11)))
            addView(spacer()); addView(recTimeS)
        }
        recTitleL = label("", 14f, white, true)
        recTimeL = label("0:00", 28f, red, true).apply { fontFeatureSettings = "tnum" }
        btnRecStop = roundBtn("■", "#FF453A") { rec?.stop?.let { sendPI(it) } }
        vRecL = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), 0, dp(20), 0)
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                addView(LinearLayout(context).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    addView(PulseDot(context, red), LinearLayout.LayoutParams(dp(10), dp(10)).apply { marginEnd = dp(8) })
                    addView(recTitleL)
                })
                addView(recTimeL)
            })
            addView(btnRecStop)
        }

        // --- Navigation ---
        navArtS = navArt(25, 8)
        navTitleS = label("", 13f, white, true).apply {
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) }
        }
        vNavS = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(16), 0)
            addView(navArtS); addView(navTitleS)
        }
        navArtL = navArt(52, 13)
        navTitleL = label("", 17f, white, true)
        navTextL = label("", 13f, grey).apply { maxLines = 2 }
        navSubL = label("", 13f, green, true)
        vNavL = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(14), dp(20), dp(12))
            addView(LinearLayout(context).apply {
                gravity = Gravity.CENTER_VERTICAL
                addView(navArtL)
                addView(LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) }
                    addView(navTitleL); addView(navTextL)
                })
            })
            addView(navSubL, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        }

        // --- Galaxy Buds2 Pro ---
        budsView = BudsView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(144), dp(117))
            onPhase = { bindBuds() }
        }
        budsTitle = label("Galaxy Buds2 Pro", 14f, white, true)
        budsLine = label("Connecté", 13f, grey)
        vBuds = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(18), 0)
            addView(budsView)
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) }
                addView(budsTitle); addView(budsLine)
            })
        }

        addLayer(vMusicS, S.MUSIC_S); addLayer(vMusicL, S.MUSIC_L)
        addLayer(vTimerS, S.TIMER_S); addLayer(vTimerL, S.TIMER_L)
        addLayer(vCharge, S.CHARGE); addLayer(vHud, S.HUD); addLayer(vBuds, S.BUDS)
        addLayer(vNavS, S.NAV_S); addLayer(vNavL, S.NAV_L)
        addLayer(vCallS, S.CALL_S); addLayer(vCallL, S.CALL_L)
        addLayer(vRecS, S.REC_S); addLayer(vRecL, S.REC_L)

        // --- Petite bulle ronde (deuxième activité) ---
        bubbleImg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        bubbleTxt = TextView(this).apply {
            gravity = Gravity.CENTER; setTypeface(typeface, Typeface.BOLD); visibility = View.GONE
        }
        bubble = FrameLayout(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
            addView(bubbleImg, FrameLayout.LayoutParams(-1, -1))
            addView(bubbleTxt, FrameLayout.LayoutParams(-1, -1))
            layoutParams = FrameLayout.LayoutParams(dp(35), dp(35)).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            }
            visibility = View.GONE; alpha = 0f
            pressEffect(this)
            setOnClickListener { pinned = secondary(); expanded = false; render() }
        }

        // Points micro (orange) et caméra (vert), à gauche de la pilule
        dotMic = Dot(this, Color.parseColor("#FF9F0A")).apply {
            layoutParams = LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginStart = dp(4) }
            visibility = View.GONE
        }
        dotCam = Dot(this, Color.parseColor("#30D158")).apply {
            layoutParams = LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginStart = dp(4) }
            visibility = View.GONE
        }
        dotsRow = LinearLayout(this).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            addView(dotCam); addView(dotMic)
            layoutParams = FrameLayout.LayoutParams(dp(20), dp(35)).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            }
        }

        val r = FrameLayout(this).apply {
            addView(pill, FrameLayout.LayoutParams(-1, -1))
            addView(bubble)
            addView(dotsRow)
        }
        root = r

        // Fenêtre : largeur FIXE (jamais redimensionnée en largeur → plus de sauts de position)
        @Suppress("DEPRECATION")
        val lockFlag = if (showLock) WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED else 0
        val winW = ((dp(340) * 1.12f).toInt() + 2 * (dp(35) + dp(8))) and 1.inv()
        val lp = WindowManager.LayoutParams(
            winW, dp(35),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or lockFlag,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dpa(topDp); x = dpa(xDp)
        }
        wm.addView(r, lp)

        bubbleShown = false
        tW = dp(120); tH = dp(35)
        setPillSize(tW.toFloat(), tH.toFloat())
    }

    // ---------- Quelle activité est affichée ? ----------
    private fun active(): List<Act> {
        val l = mutableListOf<Act>()
        if (call != null) l.add(Act.CALL)
        if (rec != null) l.add(Act.REC)
        if (nav != null) l.add(Act.NAV)
        if (timerEnd > 0) l.add(Act.TIMER)
        if (hasMusic) l.add(Act.MUSIC)
        val p = pinned
        if (p != null) { if (l.remove(p)) l.add(0, p) else pinned = null }
        return l
    }

    private fun primary(): Act? = active().firstOrNull()
    private fun secondary(): Act? = if (chargeShowing || hudShowing || budsShowing) null else active().getOrNull(1)

    private fun state(): S {
        if (budsShowing) return S.BUDS
        if (hudShowing) return S.HUD
        if (chargeShowing) return S.CHARGE
        return when (primary()) {
            Act.CALL -> if (expanded) S.CALL_L else S.CALL_S
            Act.REC -> if (expanded) S.REC_L else S.REC_S
            Act.NAV -> if (expanded) S.NAV_L else S.NAV_S
            Act.TIMER -> if (expanded) S.TIMER_L else S.TIMER_S
            Act.MUSIC -> if (expanded) S.MUSIC_L else S.MUSIC_S
            null -> S.IDLE
        }
    }

    private fun sizeOf(s: S): Pair<Int, Int> = when (s) {
        S.IDLE -> 120 to 35
        S.MUSIC_S, S.TIMER_S, S.NAV_S, S.CALL_S, S.REC_S -> 210 to 35
        S.MUSIC_L -> 340 to 136
        S.TIMER_L -> 330 to 132
        S.NAV_L -> 340 to 124
        S.CALL_L -> 340 to 90
        S.REC_L -> 300 to 100
        S.CHARGE -> 230 to 48
        S.HUD -> 270 to 48
        S.BUDS -> 340 to 128
    }

    private fun layerFor(s: S): View? = when (s) {
        S.IDLE -> null
        S.MUSIC_S -> vMusicS
        S.MUSIC_L -> vMusicL
        S.TIMER_S -> vTimerS
        S.TIMER_L -> vTimerL
        S.CHARGE -> vCharge
        S.HUD -> vHud
        S.BUDS -> vBuds
        S.NAV_S -> vNavS
        S.NAV_L -> vNavL
        S.CALL_S -> vCallS
        S.CALL_L -> vCallL
        S.REC_S -> vRecS
        S.REC_L -> vRecL
    }

    private fun render() {
        if (root == null) return
        val pr = primary()
        if (pr != lastPrimary) {
            expanded = (pr == Act.CALL && wantCallOpen)
            wantCallOpen = false
            lastPrimary = pr
        }
        val s = state()
        showLayer(layerFor(s))
        val sec = secondary()
        bindBubble(sec)
        showBubble(sec != null)
        val (w, h) = sizeOf(s)
        animateTo(dp(w), dp(h))
    }

    /** Fondu + léger zoom entre les contenus, comme sur la démo web. */
    private fun showLayer(target: View?) {
        for (v in layers) {
            if (v === target) {
                if (v.visibility != View.VISIBLE) {
                    v.alpha = 0f; v.scaleX = 0.92f; v.scaleY = 0.92f; v.visibility = View.VISIBLE
                }
                v.animate().alpha(1f).scaleX(1f).scaleY(1f)
                    .setStartDelay(120).setDuration(300).start()
            } else if (v.visibility == View.VISIBLE) {
                v.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f)
                    .setStartDelay(0).setDuration(100)
                    .withEndAction { if (v.alpha < 0.05f) v.visibility = View.GONE }.start()
            }
        }
    }

    // ---------- Bulle ----------
    private fun showBubble(show: Boolean) {
        if (show == bubbleShown) return
        bubbleShown = show
        if (show) {
            bubble.visibility = View.VISIBLE
            bubble.alpha = 0f; bubble.scaleX = 0.3f; bubble.scaleY = 0.3f
            bubble.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setStartDelay(100).setDuration(400)
                .setInterpolator(PathInterpolator(0.34f, 1.45f, 0.5f, 1f)).start()
        } else {
            bubble.animate().alpha(0f).scaleX(0.3f).scaleY(0.3f)
                .setStartDelay(0).setDuration(180).setInterpolator(LinearInterpolator())
                .withEndAction { if (!bubbleShown) bubble.visibility = View.GONE }.start()
        }
    }

    private fun bindBubble(sec: Act?) {
        bubbleImg.visibility = View.GONE; bubbleTxt.visibility = View.GONE
        when (sec) {
            Act.MUSIC -> {
                bubbleImg.visibility = View.VISIBLE
                bubbleImg.setPadding(0, 0, 0, 0)
                bubbleImg.scaleType = ImageView.ScaleType.CENTER_CROP
                bubbleImg.background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                    intArrayOf(Color.parseColor("#FF375F"), Color.parseColor("#5E5CE6")))
                bubbleImg.setImageBitmap(musicBmp)
            }
            Act.NAV -> {
                bubbleImg.visibility = View.VISIBLE
                val p = dp(7); bubbleImg.setPadding(p, p, p, p)
                bubbleImg.scaleType = ImageView.ScaleType.FIT_CENTER
                bubbleImg.setBackgroundColor(Color.parseColor("#0A84FF"))
                val ic = nav?.icon
                if (ic != null) bubbleImg.setImageBitmap(ic)
                else bubbleImg.setImageResource(android.R.drawable.ic_menu_directions)
            }
            Act.TIMER -> {
                bubbleTxt.visibility = View.VISIBLE
                bubbleTxt.text = timerText; bubbleTxt.textSize = 11f * scale
                bubbleTxt.setTextColor(Color.parseColor("#FF9F0A"))
            }
            Act.CALL -> {
                bubbleTxt.visibility = View.VISIBLE
                bubbleTxt.text = "📞"; bubbleTxt.textSize = 15f * scale
                bubbleTxt.setTextColor(Color.parseColor("#30D158"))
            }
            Act.REC -> {
                bubbleTxt.visibility = View.VISIBLE
                bubbleTxt.text = "●"; bubbleTxt.textSize = 16f * scale
                bubbleTxt.setTextColor(Color.parseColor("#FF453A"))
            }
            null -> {}
        }
    }

    // ---------- Animation (dessin seul, aucune mise en page) ----------
    private fun setPillSize(w: Float, h: Float) {
        pill.setSize(w, h)
        if (::bubble.isInitialized) bubble.translationX = (w + dp(35)) / 2f + dp(8)
        if (::dotsRow.isInitialized) dotsRow.translationX = -(w / 2f) - dp(16)
    }

    private fun setWindowHeight(h: Int) {
        val r = root ?: return
        val lp = r.layoutParams as? WindowManager.LayoutParams ?: return
        val hh = maxOf(h, dp(35))
        if (lp.height == hh) return
        lp.height = hh
        wm.updateViewLayout(r, lp)
    }

    private fun animateTo(w1: Int, h1: Int) {
        if (root == null) return
        if (w1 == tW && h1 == tH) {
            if (anim?.isRunning != true) setWindowHeight(h1)
            return
        }
        tW = w1; tH = h1
        val w0 = pill.pw; val h0 = pill.ph
        anim?.cancel()
        setWindowHeight((maxOf(h0, h1.toFloat()) * 1.15f).toInt())
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 520
            interpolator = PathInterpolator(0.34f, 1.45f, 0.5f, 1f)
            addUpdateListener {
                val f = it.animatedValue as Float
                setPillSize(w0 + (w1 - w0) * f, h0 + (h1 - h0) * f)
            }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: Animator) { cancelled = true }
                override fun onAnimationEnd(a: Animator) {
                    if (cancelled) return
                    setPillSize(w1.toFloat(), h1.toFloat())
                    setWindowHeight(h1)
                }
            })
            start()
        }
    }

    private fun toggle() {
        val s = state()
        if (s == S.IDLE || s == S.CHARGE || s == S.HUD || s == S.BUDS) return
        expanded = !expanded
        render()
        updateTicker()
    }

    // ---------- Données venant des notifications ----------
    private fun onBridge() {
        handler.post {
            if (root == null) return@post
            val hadCall = call != null
            nav = Bridge.nav
            call = Bridge.call
            rec = Bridge.rec
            val c = call
            if (c != null && !hadCall && c.answer != null) wantCallOpen = true

            val end = Bridge.clockEnd
            if (end > 0) {
                val left = end - System.currentTimeMillis()
                if (left > 0) {
                    timerEnd = SystemClock.elapsedRealtime() + left
                    timerExternal = true
                    timerPaused = Bridge.clockPaused
                    timerLeftMs = left
                    handler.removeCallbacks(timerTick); handler.post(timerTick)
                }
            } else if (timerExternal) {
                timerExternal = false; timerPaused = false; timerEnd = 0
                handler.removeCallbacks(timerTick)
            }
            refresh()
        }
    }

    private fun bindNav() {
        val n = nav ?: return
        navTitleS.text = n.title.ifBlank { n.text }
        navTitleL.text = n.title
        navTextL.text = n.text
        navTextL.visibility = if (n.text.isBlank()) View.GONE else View.VISIBLE
        navSubL.text = n.sub
        navSubL.visibility = if (n.sub.isBlank()) View.GONE else View.VISIBLE
        for (v in listOf(navArtS, navArtL)) {
            if (n.icon != null) v.setImageBitmap(n.icon)
            else v.setImageResource(android.R.drawable.ic_menu_directions)
        }
    }

    private fun bindCall() {
        val c = call ?: return
        callNameL.text = c.name
        btnAnswer.visibility = if (c.answer != null) View.VISIBLE else View.GONE
        for (v in listOf(callArtS, callArtL)) {
            if (c.icon != null) v.setImageBitmap(c.icon)
            else v.setImageResource(android.R.drawable.sym_action_call)
        }
        bindTimes()
    }

    private fun bindRec() {
        val r = rec ?: return
        recTitleL.text = r.label
        btnRecStop.visibility = if (r.stop != null) View.VISIBLE else View.GONE
        bindTimes()
    }

    private fun fmt(ms: Long): String {
        val sec = (ms / 1000).coerceAtLeast(0)
        return if (sec >= 3600) "%d:%02d:%02d".format(sec / 3600, (sec % 3600) / 60, sec % 60)
        else "%d:%02d".format(sec / 60, sec % 60)
    }

    private fun bindTimes() {
        val c = call
        if (c != null) {
            val d = if (c.since > 0) fmt(System.currentTimeMillis() - c.since) else c.status
            callDurS.text = d; callStatusL.text = d
        }
        val r = rec
        if (r != null) {
            val d = if (r.since > 0) fmt(System.currentTimeMillis() - r.since) else "—"
            recTimeS.text = d; recTimeL.text = d
        }
    }

    private val timesTick = object : Runnable {
        override fun run() {
            bindTimes()
            if (call != null || rec != null) handler.postDelayed(this, 500)
        }
    }

    // ---------- Musique ----------
    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = refresh()
        override fun onMetadataChanged(metadata: MediaMetadata?) = refresh()
    }
    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private fun setupMusic() {
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(this, MusicListener::class.java)
            msm.removeOnActiveSessionsChangedListener(sessionsListener)
            msm.addOnActiveSessionsChangedListener(sessionsListener, cn)
            pick(msm.getActiveSessions(cn))
        } catch (e: SecurityException) {
            // accès aux notifications pas encore autorisé
        }
    }

    private fun pick(list: List<MediaController>?) {
        controller?.unregisterCallback(callback)
        controller = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        controller?.registerCallback(callback)
        refresh()
    }

    private fun accent(b: Bitmap?): Int {
        if (b == null) return Color.parseColor("#FF375F")
        return try {
            val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3); Color.colorToHSV(px, hsv)
            hsv[1] = maxOf(hsv[1], 0.5f); hsv[2] = 1f
            Color.HSVToColor(hsv)
        } catch (e: Exception) { Color.parseColor("#FF375F") }
    }

    private fun refresh() {
        handler.post {
            if (root == null) return@post
            val c = controller
            val st = c?.playbackState?.state
            val live = st == PlaybackState.STATE_PLAYING || st == PlaybackState.STATE_BUFFERING ||
                st == PlaybackState.STATE_CONNECTING || st == PlaybackState.STATE_SKIPPING_TO_NEXT ||
                st == PlaybackState.STATE_SKIPPING_TO_PREVIOUS
            playing = live
            val md = c?.metadata
            val newTitle = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            if (newTitle != null) {
                lastArtist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
                val b = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                if (b != null || newTitle != lastTitle) lastBmp = b
                lastTitle = newTitle
            }
            // Pendant un changement de morceau, la session passe brièvement par un état vide :
            // on garde l'îlot affiché 2,5 s avant de le replier, pour qu'il ne « se détache » pas.
            val musicNow = c != null && (live || st == PlaybackState.STATE_PAUSED) && lastTitle != null
            if (musicNow) {
                handler.removeCallbacks(musicHide); hidePending = false
                hasMusic = true
            } else if (hasMusic && !hidePending) {
                hidePending = true
                handler.postDelayed(musicHide, 2500)
            }
            val title = lastTitle; val bmp = lastBmp
            if (title != null) {
                val changed = shownTitle != null && shownTitle != title
                titleL.text = title; artistL.text = lastArtist
                artS.setImageBitmap(bmp); artL.setImageBitmap(bmp)
                musicBmp = bmp
                shownTitle = title
                if (changed) animateTrackChange()
            }
            val col = accent(bmp)
            eqS.setColor(col); eqL.setColor(col)
            val act = playing && hasMusic
            eqS.setActive(act); eqL.setActive(act)
            playIcon.set(if (playing) 2 else 1)

            bindNav(); bindCall(); bindRec()
            bindTimerUi()
            render()
            updateTicker()
            handler.removeCallbacks(timesTick)
            if (call != null || rec != null) handler.post(timesTick)
        }
    }

    private val musicHide = Runnable {
        hidePending = false; hasMusic = false
        lastTitle = null; shownTitle = null; lastBmp = null; musicBmp = null
        render()
    }

    /** Changement de morceau : la pochette « pop », le texte glisse depuis le côté du bouton appuyé. */
    private fun animateTrackChange() {
        for (v in listOf(artL, artS)) {
            v.scaleX = 0.8f; v.scaleY = 0.8f
            v.animate().scaleX(1f).scaleY(1f).setDuration(420)
                .setInterpolator(OvershootInterpolator(2f)).start()
        }
        for (v in listOf(titleL, artistL)) {
            v.alpha = 0f; v.translationX = slideDir * dp(24).toFloat()
            v.animate().alpha(1f).translationX(0f).setStartDelay(60).setDuration(320)
                .setInterpolator(PathInterpolator(0.2f, 0.8f, 0.2f, 1f)).start()
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            val c = controller; val st = c?.playbackState
            val dur = c?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
            if (st != null && dur > 0) {
                var pos = st.position
                if (st.state == PlaybackState.STATE_PLAYING)
                    pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
                progressView.progress = pos.toFloat() / dur
            } else progressView.progress = 0f
            if (state() == S.MUSIC_L && playing) handler.postDelayed(this, 500)
        }
    }

    private fun updateTicker() {
        handler.removeCallbacks(ticker)
        if (state() == S.MUSIC_L) handler.post(ticker)
    }

    // ---------- Minuteur (pause, reprise, +/- 1 min) ----------
    private fun leftSec(): Int =
        if (timerPaused) ((timerLeftMs + 999) / 1000).toInt()
        else ((timerEnd - SystemClock.elapsedRealtime() + 999) / 1000).toInt()

    private val timerTick = object : Runnable {
        override fun run() {
            val left = leftSec()
            if (left <= 0) { timerEnd = 0; timerPaused = false; timerExternal = false; render(); return }
            val txt = if (left >= 3600) "%d:%02d:%02d".format(left / 3600, (left % 3600) / 60, left % 60)
                      else "%d:%02d".format(left / 60, left % 60)
            tmS.text = txt; tmL.text = txt
            timerText = txt
            if (::bubbleTxt.isInitialized && secondary() == Act.TIMER) bubbleTxt.text = txt
            if (!timerPaused) handler.postDelayed(this, 250)
        }
    }

    private fun bindTimerUi() {
        if (!::timerPlay.isInitialized) return
        timerPlay.set(if (timerPaused) 1 else 2)
        val own = !timerExternal
        val vis = if (own) View.VISIBLE else View.GONE
        chipMinus.visibility = vis; chipPlus.visibility = vis; stopTimerBtn.visibility = vis
        timerPlay.visibility = if (own || Bridge.clockToggle != null) View.VISIBLE else View.GONE
        val a = if (timerPaused) 0.5f else 1f
        tmS.alpha = a; tmL.alpha = a
    }

    private fun startTimer(sec: Int) {
        timerExternal = false; timerPaused = false
        timerEnd = SystemClock.elapsedRealtime() + sec * 1000L
        handler.removeCallbacks(timerTick); handler.post(timerTick)
        refresh()
    }

    private fun stopTimer() {
        timerEnd = 0; timerPaused = false; timerExternal = false
        handler.removeCallbacks(timerTick)
        expanded = false
        render()
    }

    /** Pause / reprise. Pour un minuteur de l'appli Horloge, on utilise le bouton de sa notification. */
    private fun toggleTimer() {
        if (timerExternal) { Bridge.clockToggle?.let { sendPI(it) }; return }
        if (timerPaused) {
            timerPaused = false
            timerEnd = SystemClock.elapsedRealtime() + timerLeftMs
        } else {
            timerLeftMs = (timerEnd - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
            timerPaused = true
        }
        handler.removeCallbacks(timerTick); handler.post(timerTick)
        bindTimerUi()
    }

    private fun addTime(delta: Long) {
        if (timerExternal) return
        if (timerPaused) timerLeftMs = (timerLeftMs + delta).coerceAtLeast(1000L)
        else timerEnd = maxOf(timerEnd + delta, SystemClock.elapsedRealtime() + 1000L)
        handler.removeCallbacks(timerTick); handler.post(timerTick)
    }

    // ---------- Ouvrir une appli, raccrocher ----------
    private fun sendPI(pi: PendingIntent): Boolean = try {
        if (Build.VERSION.SDK_INT >= 34) {
            val o = ActivityOptions.makeBasic()
            o.setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_START_ALLOWED)
            pi.send(this, 0, null, null, null, null, o.toBundle())
        } else pi.send()
        true
    } catch (e: Exception) { false }

    private fun launchPkg(pkg: String) {
        if (pkg.isBlank()) return
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(i) } catch (_: Exception) {}
    }

    private fun openApp(pi: PendingIntent?, pkg: String) {
        if (pi == null || !sendPI(pi)) launchPkg(pkg)
    }

    /** Appui long : ouvre l'appli de l'activité principale (Spotify, Maps, Téléphone...). */
    private fun openPrimaryApp() {
        val s = state()
        if (s == S.IDLE || s == S.CHARGE || s == S.HUD || s == S.BUDS) return
        when (primary()) {
            Act.MUSIC -> {
                val c = controller
                val pi = c?.sessionActivity
                if (pi != null && sendPI(pi)) return
                c?.packageName?.let { launchPkg(it) }
            }
            Act.NAV -> nav?.let { openApp(it.openPi, it.pkg) }
            Act.CALL -> call?.let { openApp(it.openPi, it.pkg) }
            Act.REC -> rec?.let { openApp(it.openPi, it.pkg) }
            Act.TIMER -> if (timerExternal) openApp(Bridge.clockOpen, Bridge.clockPkg) else launchPkg(packageName)
            null -> {}
        }
    }

    private fun hangUp() {
        val pi = call?.hangup
        if (pi != null && sendPI(pi)) return
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ANSWER_PHONE_CALLS)
                == PackageManager.PERMISSION_GRANTED)
                getSystemService(TelecomManager::class.java).endCall()
        } catch (_: Exception) {}
    }

    // ---------- Charge, silencieux, volume, ne pas déranger ----------
    private val transientHide = Runnable {
        pulseAnim?.cancel(); pulseAnim = null
        if (::batt.isInitialized) { batt.alpha = 1f; boltTxt.alpha = 1f }
        chargeShowing = false; hudShowing = false; budsShowing = false; render()
    }

    /** Couleur selon le niveau : rouge, orange, jaune, vert. */
    private fun battColor(pct: Int) = Color.parseColor(when {
        pct <= 15 -> "#FF453A"
        pct <= 30 -> "#FF9F0A"
        pct <= 60 -> "#FFD60A"
        else -> "#30D158"
    })

    private fun flashBattery(pct: Int, charging: Boolean) {
        val c = if (charging) battColor(pct) else Color.parseColor("#FF453A")
        chargeLabel.text = when {
            charging && pct >= 100 -> "  Chargée"
            charging -> "  En charge"
            else -> "  Batterie faible"
        }
        boltTxt.text = if (charging) "⚡" else "⚠"
        boltTxt.setTextColor(c)
        batt.fillColor = c
        chargeTxt.text = "$pct%"; chargeTxt.setTextColor(c)
        pulseAnim?.cancel(); batt.alpha = 1f; boltTxt.alpha = 1f
        if (charging) batt.animateTo(pct) else batt.level = pct
        pulseAnim = ObjectAnimator.ofFloat(if (charging) boltTxt else batt, "alpha", 1f, 0.3f).apply {
            duration = 450; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
            start()
        }
        chargeShowing = true; hudShowing = false; budsShowing = false
        render()
        handler.removeCallbacks(transientHide)
        handler.postDelayed(transientHide, if (charging) 3000L else 4500L)
    }

    private fun popEmoji() {
        hudEmoji.scaleX = 0.4f; hudEmoji.scaleY = 0.4f
        hudEmoji.animate().scaleX(1f).scaleY(1f).setDuration(420)
            .setInterpolator(OvershootInterpolator(2.5f)).start()
    }

    private fun flashHud(emoji: String, text: String, level: Float?,
                         status: String = "", statusColor: Int = Color.WHITE) {
        hudEmoji.text = emoji; hudLabel.text = text
        hudStatus.text = status; hudStatus.setTextColor(statusColor)
        hudStatus.visibility = if (status.isEmpty()) View.GONE else View.VISIBLE
        if (level == null) hudBar.visibility = View.GONE
        else { hudBar.visibility = View.VISIBLE; hudBar.progress = level }
        hudShowing = true; chargeShowing = false; budsShowing = false
        render(); popEmoji()
        handler.removeCallbacks(transientHide); handler.postDelayed(transientHide, 2400)
    }

    /** Cadenas qui s'ouvre au déverrouillage. */
    private fun flashUnlock(face: Boolean) {
        val label = if (face) "Visage reconnu" else "Déverrouillé"
        flashHud("🔒", label, null)
        handler.postDelayed({
            if (hudShowing && hudLabel.text == label) {
                hudEmoji.text = "🔓"; popEmoji()
                hudStatus.text = "✓"; hudStatus.setTextColor(Color.parseColor("#30D158"))
                hudStatus.visibility = View.VISIBLE
            }
        }, 380)
    }

    private fun faceUnlockEnabled(): Boolean = try {
        Settings.Secure.getInt(contentResolver, "face_unlock_keyguard_enabled", 0) == 1
    } catch (e: Exception) { false }

    private val systemReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (root == null) return
            val audio = getSystemService(AudioManager::class.java)
            when (i.action) {
                Intent.ACTION_POWER_CONNECTED -> {
                    val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                    val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
                    val max = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
                    flashBattery(if (max > 0) level * 100 / max else level, true)
                }
                Intent.ACTION_BATTERY_CHANGED -> {
                    val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                    val max = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                    val pct = if (max > 0) level * 100 / max else level
                    val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
                    val t = listOf(20, 15, 10, 5).filter { pct <= it }.minOrNull()
                    if (plugged || t == null) lastWarn = Int.MAX_VALUE
                    else if (t < lastWarn) {
                        lastWarn = t
                        if (!battFirst) flashBattery(pct, false)
                    }
                    battFirst = false
                }
                PowerManager.ACTION_POWER_SAVE_MODE_CHANGED -> {
                    val on = getSystemService(PowerManager::class.java).isPowerSaveMode
                    val v = if (on) 1 else 0
                    if (v != lastSaver) {
                        lastSaver = v
                        flashHud("🔋", "Économie d'énergie", null,
                            if (on) "Activée" else "Désactivée",
                            Color.parseColor(if (on) "#FFD60A" else "#9A9AA6"))
                    }
                }
                Intent.ACTION_SCREEN_ON -> screenOnAt = SystemClock.elapsedRealtime()
                Intent.ACTION_USER_PRESENT -> if (useUnlock) {
                    val quick = SystemClock.elapsedRealtime() - screenOnAt < 2500
                    flashUnlock(quick && faceUnlockEnabled())
                }
                AudioManager.RINGER_MODE_CHANGED_ACTION -> {
                    val mode = audio.ringerMode
                    if (mode != lastRinger) {
                        val first = lastRinger == -1
                        lastRinger = mode
                        if (!first) when (mode) {
                            AudioManager.RINGER_MODE_SILENT -> flashHud("🔕", "Silencieux", null)
                            AudioManager.RINGER_MODE_VIBRATE -> flashHud("📳", "Vibreur", null)
                            else -> flashHud("🔔", "Sonnerie", null)
                        }
                    }
                }
                "android.media.VOLUME_CHANGED_ACTION" -> {
                    val type = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
                    val v = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", -1)
                    val name = when (type) {
                        AudioManager.STREAM_RING -> "Sonnerie"
                        AudioManager.STREAM_NOTIFICATION -> "Notifications"
                        AudioManager.STREAM_ALARM -> "Alarme"
                        else -> null
                    }
                    if (name != null && v >= 0) {
                        val max = audio.getStreamMaxVolume(type).coerceAtLeast(1)
                        flashHud(if (type == AudioManager.STREAM_ALARM) "⏰" else "🔔", name, v.toFloat() / max)
                    }
                }
                NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED -> {
                    val f = getSystemService(NotificationManager::class.java).currentInterruptionFilter
                    if (f != lastDnd) {
                        val first = lastDnd == -1
                        lastDnd = f
                        if (!first) {
                            if (f == NotificationManager.INTERRUPTION_FILTER_ALL)
                                flashHud("🔔", "Ne pas déranger : off", null)
                            else flashHud("🌙", "Ne pas déranger", null)
                        }
                    }
                }
            }
        }
    }

    // ---------- Galaxy Buds2 Pro ----------
    private val budsCb = object : BudsMonitor.Callback {
        override fun onBudsConnected() { handler.post { flashBuds(true) } }
        override fun onBudsDisconnected() { handler.post { flashBuds(false) } }
        override fun onBudsInfo() { handler.post { bindBuds() } }
    }

    private fun startBuds() {
        if (!useBuds) { budsMon?.stop(); budsMon = null; return }
        val m = budsMon ?: BudsMonitor(this, handler, budsCb).also { budsMon = it }
        m.detailed = budsDetail
        m.start()
    }

    private fun bindBuds() {
        if (!::budsView.isInitialized) return
        val i = budsMon?.info
        val l = i?.left ?: -1
        val r = i?.right ?: -1
        // Un seul écouteur actif : on précise lequel. Les deux (ou inconnu) : aucune précision.
        budsView.which = when {
            l > 0 && r <= 0 -> 1
            r > 0 && l <= 0 -> 2
            else -> 0
        }
        // Pendant l'animation, le texte suit les images ; à la fin, on affiche la batterie.
        if (!budsView.finished) { budsLine.text = budsView.phaseText; return }
        if (!budsConnected) { budsLine.text = "Déconnectés"; return }
        val sb = StringBuilder()
        if (i != null && (l > 0 || r > 0)) {
            when (budsView.which) {
                1 -> sb.append("L ").append(l).append('%')
                2 -> sb.append("R ").append(r).append('%')
                else -> sb.append("L ").append(l).append("%   R ").append(r).append('%')
            }
            if (i.caseLvl > 0) sb.append("   Étui ").append(i.caseLvl).append('%')
        } else if (i != null && i.single >= 0) sb.append("Batterie ").append(i.single).append('%')
        else sb.append("Connectés")
        budsLine.text = sb.toString()
    }

    private fun flashBuds(connected: Boolean) {
        if (root == null || !::budsView.isInitialized) return
        budsConnected = connected
        budsView.play(connected)
        bindBuds()
        budsShowing = true; chargeShowing = false; hudShowing = false
        render()
        handler.removeCallbacks(transientHide)
        handler.postDelayed(transientHide, if (connected) 6500L else 4200L)
    }

    // ---------- Points micro / caméra ----------
    private val camCb = object : CameraManager.AvailabilityCallback() {
        override fun onCameraUnavailable(cameraId: String) { camBusy.add(cameraId); updateDots() }
        override fun onCameraAvailable(cameraId: String) { camBusy.remove(cameraId); updateDots() }
    }
    private val micCb = object : AudioManager.AudioRecordingCallback() {
        override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>?) {
            micOn = !configs.isNullOrEmpty(); updateDots()
        }
    }

    private fun registerPrivacy() {
        if (privacyRegistered) return
        privacyRegistered = true
        try { getSystemService(CameraManager::class.java).registerAvailabilityCallback(camCb, handler) } catch (_: Exception) {}
        try { getSystemService(AudioManager::class.java).registerAudioRecordingCallback(micCb, handler) } catch (_: Exception) {}
    }

    private fun updateDots() {
        if (root == null || !::dotCam.isInitialized) return
        setDot(dotCam, useDots && camBusy.isNotEmpty())
        setDot(dotMic, useDots && micOn)
    }

    private fun setDot(d: View, show: Boolean) {
        val shown = d.visibility == View.VISIBLE
        if (show == shown) return
        if (show) {
            d.visibility = View.VISIBLE; d.scaleX = 0f; d.scaleY = 0f
            d.animate().scaleX(1f).scaleY(1f).setDuration(300)
                .setInterpolator(OvershootInterpolator(3f)).start()
        } else {
            d.animate().scaleX(0f).scaleY(0f).setDuration(150)
                .withEndAction { if (d.scaleX < 0.05f) d.visibility = View.GONE }.start()
        }
    }

    private fun registerSystem() {
        if (receiverRegistered) return
        try {
            lastRinger = getSystemService(AudioManager::class.java).ringerMode
            lastDnd = getSystemService(NotificationManager::class.java).currentInterruptionFilter
            lastSaver = if (getSystemService(PowerManager::class.java).isPowerSaveMode) 1 else 0
        } catch (_: Exception) {}
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction("android.media.VOLUME_CHANGED_ACTION")
            addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
        }
        ContextCompat.registerReceiver(this, systemReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        receiverRegistered = true
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        anim?.cancel()
        Bridge.listener = null
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        try { if (receiverRegistered) unregisterReceiver(systemReceiver) } catch (_: Exception) {}
        receiverRegistered = false
        try {
            getSystemService(MediaSessionManager::class.java)
                .removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Exception) {}
        controller?.unregisterCallback(callback)
        budsMon?.stop()
        if (privacyRegistered) {
            try { getSystemService(CameraManager::class.java).unregisterAvailabilityCallback(camCb) } catch (_: Exception) {}
            try { getSystemService(AudioManager::class.java).unregisterAudioRecordingCallback(micCb) } catch (_: Exception) {}
            privacyRegistered = false
        }
        root?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        root = null
        super.onDestroy()
    }
}
