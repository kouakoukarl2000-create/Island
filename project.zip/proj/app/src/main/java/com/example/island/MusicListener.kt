package com.example.island

import android.app.Notification
import android.app.PendingIntent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class NavInfo(
    val title: String, val text: String, val sub: String, val icon: Bitmap?,
    val openPi: PendingIntent?, val pkg: String
)
data class CallInfo(
    val name: String, val status: String, val since: Long, val icon: Bitmap?,
    val hangup: PendingIntent?, val answer: PendingIntent?, val openPi: PendingIntent?, val pkg: String
)
data class RecInfo(val label: String, val since: Long, val stop: PendingIntent?, val openPi: PendingIntent?, val pkg: String)

/** Pont entre le service d'écoute des notifications et l'îlot. */
object Bridge {
    var nav: NavInfo? = null
    var call: CallInfo? = null
    var rec: RecInfo? = null
    var clockEnd: Long = 0L          // fin du minuteur de l'appli Horloge (ms, horloge murale)
    var clockOpen: PendingIntent? = null
    var clockPkg: String = ""
    var listener: (() -> Unit)? = null
    fun changed() { listener?.invoke() }
}

/**
 * Sert à lire les lecteurs de musique (autorisation) et les notifications :
 * navigation Google Maps, appels, enregistrements, minuteur de l'appli Horloge.
 */
class MusicListener : NotificationListenerService() {
    companion object {
        @Volatile var instance: MusicListener? = null
    }

    private val maps = "com.google.android.apps.maps"

    override fun onListenerConnected() { instance = this; scanAll() }
    override fun onListenerDisconnected() { instance = null }
    override fun onNotificationPosted(sbn: StatusBarNotification) { scanAll() }
    override fun onNotificationRemoved(sbn: StatusBarNotification) { scanAll() }

    private fun scanAll() {
        val all: List<StatusBarNotification> =
            try { activeNotifications?.toList() } catch (e: Exception) { null } ?: return

        val navList = all.filter { it.packageName == maps }
        val navSbn = navList.firstOrNull { it.notification.category == Notification.CATEGORY_NAVIGATION }
            ?: navList.firstOrNull { it.isOngoing }

        val callList = all.filter { it.notification.category == Notification.CATEGORY_CALL }
        val callSbn = callList.firstOrNull { it.isOngoing } ?: callList.firstOrNull()

        val recSbn = all.firstOrNull {
            it.packageName != maps && it.packageName != packageName &&
                it.notification.category != Notification.CATEGORY_CALL && it.isOngoing && looksLikeRecording(it)
        }

        var clockEnd = 0L; var clockOpen: PendingIntent? = null; var clockPkg = ""
        for (s in all) {
            val t = clockTimer(s)
            if (t != null) { clockEnd = t; clockOpen = s.notification.contentIntent; clockPkg = s.packageName; break }
        }

        Bridge.nav = navSbn?.let { parseNav(it) }
        Bridge.call = callSbn?.let { parseCall(it) }
        Bridge.rec = recSbn?.let { parseRec(it) }
        Bridge.clockEnd = clockEnd; Bridge.clockOpen = clockOpen; Bridge.clockPkg = clockPkg
        Bridge.changed()
    }

    private fun str(n: Notification, key: String) =
        n.extras.getCharSequence(key)?.toString()?.trim().orEmpty()

    private fun allText(n: Notification): String {
        val e = n.extras
        val sb = StringBuilder()
        for (k in listOf(Notification.EXTRA_TITLE, Notification.EXTRA_TEXT, Notification.EXTRA_SUB_TEXT,
            Notification.EXTRA_BIG_TEXT, Notification.EXTRA_INFO_TEXT)) sb.append(str(n, k)).append(' ')
        e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.forEach { sb.append(it).append(' ') }
        return sb.toString()
    }

    private fun icon(n: Notification): Bitmap? = try {
        (n.getLargeIcon() ?: n.smallIcon)?.loadDrawable(this)?.let { toBitmap(it) }
    } catch (ex: Exception) { null }

    private fun findAction(n: Notification, keys: List<String>): PendingIntent? =
        n.actions?.firstOrNull { a ->
            val t = a.title?.toString()?.lowercase() ?: ""
            keys.any { t.contains(it) }
        }?.actionIntent

    // ----- navigation -----
    private fun parseNav(sbn: StatusBarNotification): NavInfo {
        val n = sbn.notification
        val title = str(n, Notification.EXTRA_TITLE).ifBlank { str(n, Notification.EXTRA_TITLE_BIG) }
        val text = str(n, Notification.EXTRA_TEXT).ifBlank { str(n, Notification.EXTRA_BIG_TEXT) }
        val sub = str(n, Notification.EXTRA_SUB_TEXT).ifBlank { str(n, Notification.EXTRA_INFO_TEXT) }
        return NavInfo(title.ifBlank { "Navigation" }, text, sub, icon(n), n.contentIntent, sbn.packageName)
    }

    // ----- appels -----
    private fun parseCall(sbn: StatusBarNotification): CallInfo {
        val n = sbn.notification
        val since = if (n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)) n.`when` else 0L
        val acts = n.actions?.toList() ?: emptyList()
        val answer = findAction(n, listOf("répond", "repond", "answer", "accept", "décroch", "decroch"))
        var hang = findAction(n, listOf("raccroch", "hang", "end", "terminer", "refus", "decline", "reject", "dismiss"))
        if (hang == null) {
            // Aucun libellé reconnu : appel en cours = dernière action ; appel entrant = première action qui n'est pas « répondre »
            hang = if (answer == null) acts.lastOrNull()?.actionIntent
                   else acts.firstOrNull { it.actionIntent != null && it.actionIntent != answer }?.actionIntent
        }
        return CallInfo(str(n, Notification.EXTRA_TITLE).ifBlank { "Appel" },
            str(n, Notification.EXTRA_TEXT), since, icon(n), hang, answer, n.contentIntent, sbn.packageName)
    }

    // ----- enregistrements (écran ou dictaphone) -----
    private fun looksLikeRecording(sbn: StatusBarNotification): Boolean {
        val t = allText(sbn.notification).lowercase()
        return t.contains("enregistr") || t.contains("record")
    }

    private fun parseRec(sbn: StatusBarNotification): RecInfo {
        val n = sbn.notification
        val since = if (n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)) n.`when` else 0L
        val title = str(n, Notification.EXTRA_TITLE).ifBlank { "Enregistrement" }
        val stop = findAction(n, listOf("arrêt", "arret", "stop", "terminer", "fin"))
        return RecInfo(title, since, stop, n.contentIntent, sbn.packageName)
    }

    // ----- minuteur (appli Horloge, ou toute appli avec un compte à rebours) -----
    private fun clockTimer(sbn: StatusBarNotification): Long? {
        val n = sbn.notification; val e = n.extras
        if (sbn.packageName == maps || sbn.packageName == packageName ||
            n.category == Notification.CATEGORY_CALL) return null
        val chrono = e.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)
        val down = e.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN)
        if (chrono && down && n.`when` > System.currentTimeMillis()) return n.`when`
        if (chrono) return null   // chronomètre ou enregistrement : pas un minuteur

        val p = sbn.packageName
        val clockPkg = p.contains("clock", true) || p.contains("alarm", true) || p.contains("timer", true)
        if (!clockPkg || !sbn.isOngoing) return null
        val txt = allText(n).lowercase()
        val words = listOf("minuteur", "timer", "minuterie", "temporisateur", "compte à rebours", "compte a rebours", "countdown")
        val alarm = txt.contains("alarme") || txt.contains("alarm")
        if (alarm && words.none { txt.contains(it) }) return null
        val m = Regex("(\\d{1,2}):(\\d{2})(?::(\\d{2}))?").find(txt) ?: return null
        val a = m.groupValues[1].toLong(); val b = m.groupValues[2].toLong()
        val c = m.groupValues[3].toLongOrNull()
        val secs = if (c != null) a * 3600 + b * 60 + c else a * 60 + b
        return if (secs > 0) System.currentTimeMillis() + secs * 1000 else null
    }

    /** Liste lisible des notifications actives (pour comprendre ce que voit l'îlot). */
    fun dump(): String {
        val all = try { activeNotifications?.toList() } catch (e: Exception) { null }
            ?: return "Accès aux notifications non autorisé (bouton 1b)."
        if (all.isEmpty()) return "Aucune notification active."
        return all.take(30).joinToString("\n\n") { s ->
            val n = s.notification; val e = n.extras
            val acts = n.actions?.joinToString(" | ") { it.title?.toString() ?: "?" } ?: "-"
            s.packageName + "\ncat=" + n.category + " ongoing=" + s.isOngoing +
                " chrono=" + e.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER) +
                " descend=" + e.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN) +
                "\ntitre=" + str(n, Notification.EXTRA_TITLE) +
                "\ntexte=" + str(n, Notification.EXTRA_TEXT) +
                "\nsous=" + str(n, Notification.EXTRA_SUB_TEXT) +
                "\nactions=" + acts
        }
    }

    private fun toBitmap(d: Drawable): Bitmap {
        val w = maxOf(d.intrinsicWidth, 1); val h = maxOf(d.intrinsicHeight, 1)
        val k = minOf(1f, 128f / maxOf(w, h))
        val bw = maxOf((w * k).toInt(), 1); val bh = maxOf((h * k).toInt(), 1)
        val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, bw, bh); d.draw(Canvas(b))
        return b
    }
}
