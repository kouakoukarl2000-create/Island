plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.island"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.island"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // Clé de signature FIXE : toutes les versions ont la même signature,
    // donc chaque mise à jour s'installe par-dessus la précédente.
    signingConfigs {
        getByName("debug") {
            storeFile = file("island.keystore")
            storePassword = "android"
            keyAlias = "island"
            keyPassword = "android"
        }
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
