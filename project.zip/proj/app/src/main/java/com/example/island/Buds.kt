package com.example.island

import android.Manifest
import android.animation.ValueAnimator
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.os.Handler
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import androidx.core.content.ContextCompat
import java.util.UUID
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

/** Niveaux de batterie connus (-1 = inconnu). */
class BudsInfo {
    var left = -1
    var right = -1
    var caseLvl = -1
    var single = -1
}

/**
 * Surveille la connexion des Galaxy Buds2 Pro (et d'eux seulement) et lit leur batterie.
 * - connexion / déconnexion : événements Bluetooth du système ;
 * - batterie globale : valeur donnée par Android, si elle existe ;
 * - batterie gauche / droite / étui : lecture expérimentale du canal propre à Samsung.
 */
class BudsMonitor(private val ctx: Context, private val handler: Handler, private val cb: Callback) {
    interface Callback {
        fun onBudsConnected()
        fun onBudsDisconnected()
        fun onBudsInfo()
    }

    companion object {
        const val ADDRESS = "41:42:FF:63:CE:F2"
        private val SPP: UUID = UUID.fromString("2e73a4ad-332d-41fc-90e2-16bef06523f2")
        private const val BATTERY_ACTION = "android.bluetooth.device.action.BATTERY_LEVEL_CHANGED"
        private const val BATTERY_EXTRA = "android.bluetooth.device.extra.BATTERY_LEVEL"
        private val logBuf = StringBuilder()

        @Synchronized
        fun log(s: String) {
            logBuf.append(s).append('\n')
            if (logBuf.length > 8000) logBuf.delete(0, logBuf.length - 6000)
        }

        @Synchronized
        fun dumpLog(): String =
            if (logBuf.isEmpty()) "Aucun événement Bluetooth reçu pour l'instant." else logBuf.toString()
    }

    val info = BudsInfo()
    var detailed = false
    private var receiver: BroadcastReceiver? = null
    private var device: BluetoothDevice? = null
    private var sppThread: Thread? = null
    private var socket: BluetoothSocket? = null
    private var pend = ByteArray(0)

    private fun hasPerm() = Build.VERSION.SDK_INT < 31 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    @Suppress("DEPRECATION")
    private fun deviceOf(i: Intent): BluetoothDevice? =
        if (Build.VERSION.SDK_INT >= 33)
            i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
        else i.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)

    private fun isBuds(d: BluetoothDevice?): Boolean {
        if (d == null) return false
        if (d.address.equals(ADDRESS, ignoreCase = true)) return true
        val n = try { if (hasPerm()) d.name else null } catch (e: SecurityException) { null }
        return n != null && n.lowercase().replace(" ", "").contains("buds2pro")
    }

    fun start() {
        if (receiver != null) return
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val d = deviceOf(i)
                when (i.action) {
                    BluetoothDevice.ACTION_ACL_CONNECTED -> if (d != null && isBuds(d)) onConnected(d)
                    BluetoothDevice.ACTION_ACL_DISCONNECTED -> if (isBuds(d)) onDisconnected()
                    BATTERY_ACTION -> if (isBuds(d)) {
                        val lvl = i.getIntExtra(BATTERY_EXTRA, -1)
                        log("Batterie (système) : $lvl")
                        if (lvl in 0..100) { info.single = lvl; cb.onBudsInfo() }
                    }
                }
            }
        }
        val f = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
            addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
            addAction(BATTERY_ACTION)
        }
        ContextCompat.registerReceiver(ctx, r, f, ContextCompat.RECEIVER_EXPORTED)
        receiver = r
        log("Surveillance Bluetooth démarrée (autorisation : " + hasPerm() + ")")
    }

    fun stop() {
        receiver?.let { try { ctx.unregisterReceiver(it) } catch (_: Exception) {} }
        receiver = null
        stopSpp()
    }

    private fun onConnected(d: BluetoothDevice) {
        device = d
        info.left = -1; info.right = -1; info.caseLvl = -1; info.single = -1
        log("Galaxy Buds2 Pro connectés")
        cb.onBudsConnected()
        for (delay in longArrayOf(1500L, 5000L, 12000L)) handler.postDelayed({ readSystemBattery() }, delay)
        if (detailed) handler.postDelayed({ startSpp(d) }, 1200L)
    }

    private fun onDisconnected() {
        log("Galaxy Buds2 Pro déconnectés")
        stopSpp()
        device = null
        cb.onBudsDisconnected()
    }

    private fun readSystemBattery() {
        val d = device ?: return
        if (!hasPerm()) return
        try {
            val v = d.javaClass.getMethod("getBatteryLevel").invoke(d) as? Int
            log("getBatteryLevel = $v")
            if (v != null && v in 0..100) { info.single = v; cb.onBudsInfo() }
        } catch (e: Exception) {
            log("getBatteryLevel indisponible : " + e.javaClass.simpleName)
        }
    }

    // ----- canal propre à Samsung (expérimental) -----
    private fun startSpp(d: BluetoothDevice) {
        stopSpp()
        if (!hasPerm()) return
        val t = Thread {
            try {
                BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
                val sock = d.createRfcommSocketToServiceRecord(SPP)
                socket = sock
                sock.connect()
                log("Canal Samsung ouvert")
                val ins = sock.inputStream
                val buf = ByteArray(1024)
                while (!Thread.currentThread().isInterrupted) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    feed(buf, n)
                }
                log("Canal Samsung fermé")
            } catch (e: Exception) {
                log("Canal Samsung : " + (e.message ?: e.javaClass.simpleName))
            }
        }
        t.isDaemon = true
        sppThread = t
        t.start()
    }

    private fun stopSpp() {
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        sppThread?.interrupt()
        sppThread = null
        pend = ByteArray(0)
    }

    private fun hex(b: ByteArray, n: Int = b.size) = (0 until n).joinToString(" ") { "%02X".format(b[it]) }

    private fun feed(b: ByteArray, n: Int) {
        log("RX " + hex(b, n))
        pend += b.copyOf(n)
        while (true) {
            val s = pend.indexOf(0xFD.toByte())
            if (s < 0) { pend = ByteArray(0); return }
            if (s > 0) pend = pend.copyOfRange(s, pend.size)
            if (pend.size < 4) return
            val size = ((pend[1].toInt() and 0xFF) or ((pend[2].toInt() and 0xFF) shl 8)) and 0x3FF
            val total = 1 + 2 + size + 1
            if (size < 3 || total > 2048) { pend = pend.copyOfRange(1, pend.size); continue }
            if (pend.size < total) return
            val id = pend[3].toInt() and 0xFF
            val payload = pend.copyOfRange(4, 4 + size - 3)
            pend = pend.copyOfRange(total, pend.size)
            handleMsg(id, payload)
        }
    }

    private fun handleMsg(id: Int, p: ByteArray) {
        log("Message 0x%02X : %s".format(id, hex(p)))
        if ((id == 0x60 || id == 0x61) && p.size >= 8) {
            fun ok(v: Int) = if (v in 0..100) v else -1
            val l = ok(p[2].toInt() and 0xFF)
            val r = ok(p[3].toInt() and 0xFF)
            val c = ok(p[7].toInt() and 0xFF)
            if (l >= 0 || r >= 0 || c >= 0) {
                info.left = l; info.right = r; info.caseLvl = c
                handler.post { cb.onBudsInfo() }
            }
        }
    }
}

/**
 * Lecteur d'images : joue la séquence de connexion (37 images tirées de ta vidéo) ou, à l'envers,
 * la séquence de déconnexion. Les images sont dans assets/buds. Le texte affiché à côté vient de l'app,
 * pas de la vidéo (celui de la vidéo était illisible).
 * which : 0 les deux, 1 gauche seul, 2 droit seul (sert à la pastille L / R).
 */
class BudsView(c: Context) : View(c) {
    var which = 0
        set(v) { field = v; invalidate() }
    var onPhase: (() -> Unit)? = null
    var phaseText = ""
        private set
    var finished = false
        private set

    private var t = 0f
    private var connectMode = true
    private var anim: ValueAnimator? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val src = Rect()
    private val dst = RectF()
    private val conn: Array<Bitmap?> by lazy { load(37) }
    private val disc: Array<Bitmap?> by lazy { conn.reversedArray() }

    private fun load(n: Int): Array<Bitmap?> = Array(n) { i ->
        try {
            context.assets.open("buds/c" + (i + 1) + ".webp").use { BitmapFactory.decodeStream(it) }
        } catch (e: Exception) { null }
    }

    private fun phaseFor(f: Float): String =
        if (connectMode) { if (f < 0.78f) "Connexion en cours..." else "Connectés ✓" }
        else when {
            f < 0.16f -> "Déconnexion en cours..."
            f < 0.42f -> "Mise dans le boîtier..."
            f < 0.80f -> "Fermeture du boîtier..."
            else -> "Déconnectés ✓"
        }

    /** connect = true : étui qui s'ouvre et écouteurs qui sortent ; false : la même séquence à l'envers. */
    fun play(connect: Boolean) {
        anim?.cancel()
        connectMode = connect
        t = 0f
        finished = false
        phaseText = phaseFor(0f)
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 3000L
            interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
        invalidate()
    }

    private fun seg(a: Float, b: Float) = ((t - a) / (b - a)).coerceIn(0f, 1f)

    private fun drawFrame(c: Canvas, b: Bitmap?, a: Int) {
        if (b == null) return
        src.set(0, 0, b.width, b.height)
        paint.alpha = a
        c.drawBitmap(b, src, dst, paint)
    }

    override fun onDraw(canvas: Canvas) {
        val frames = if (connectMode) conn else disc
        val last = frames.size - 1
        val pos = t * last
        val i = pos.toInt().coerceIn(0, last - 1)
        val p = (pos - i).coerceIn(0f, 1f)

        // on garde le rapport largeur / hauteur des images (640 x 520)
        val bw = 640f; val bh = 520f
        val k = minOf(width / bw, height / bh)
        dst.set((width - bw * k) / 2f, (height - bh * k) / 2f, (width + bw * k) / 2f, (height + bh * k) / 2f)
        val ux = dst.width() / bw

        drawFrame(canvas, frames[i], 255)
        if (p > 0f) drawFrame(canvas, frames[i + 1], (255 * p).toInt())

        // texte d'état (lu par l'îlot)
        val fin = t >= 0.999f
        val tx = phaseFor(t)
        if (tx != phaseText || fin != finished) {
            phaseText = tx; finished = fin
            post { onPhase?.invoke() }
        }

        // déconnexion : cercle avec coche au-dessus de l'étui fermé
        if (!connectMode) {
            val a = seg(0.86f, 1f)
            if (a > 0f) {
                val cx = dst.left + 320f * ux; val cy = dst.top + 82f * ux; val r = 36f * ux
                strokeP.color = ((255 * a).toInt() shl 24) or 0xFFFFFF
                strokeP.strokeWidth = 4f * ux
                canvas.drawCircle(cx, cy, r, strokeP)
                path.reset()
                path.moveTo(cx - r * 0.40f, cy + r * 0.02f)
                path.lineTo(cx - r * 0.08f, cy + r * 0.34f)
                path.lineTo(cx + r * 0.42f, cy - r * 0.30f)
                canvas.drawPath(path, strokeP)
            }
        }

        // un seul écouteur : pastille L ou R à côté de celui qui est concerné
        if (connectMode && which != 0) {
            val a = seg(0.88f, 1f)
            if (a > 0f) {
                val bx = dst.left + (if (which == 1) 105f else 535f) * ux
                val by = dst.top + 95f * ux
                fillP.style = Paint.Style.FILL
                fillP.color = ((255 * a).toInt() shl 24) or 0x30D158
                canvas.drawCircle(bx, by, 30f * ux, fillP)
                txt.color = ((255 * a).toInt() shl 24)
                txt.textSize = 34f * ux
                canvas.drawText(if (which == 1) "L" else "R", bx, by + 12f * ux, txt)
            }
        }
    }

    override fun onDetachedFromWindow() { anim?.cancel(); super.onDetachedFromWindow() }
}
